#!/usr/bin/env python3
"""
Xác minh cấu trúc gói D6 từ nhật ký cũ + file BIN gốc.

Cách dùng:
  python3 verify_d6.py file.bin nhat_ky.txt

nhat_ky.txt: mỗi gói ATT một dòng HEX (có hoặc không có khoảng trắng), ví dụ trích từ Wireshark
(Copy > as Hex Stream) hoặc từ nhật ký TX của app này. Chỉ lấy các gói bắt đầu bằng D6.

Script thử mọi kích thước header (1..12 byte) và trailer (0..4 byte) và báo cấu hình nào làm
phần ghép lại của các gói TRÙNG KHỚP với file BIN. Nếu không cấu hình nào khớp, in ra các byte đầu/cuối
của vài gói để bạn tự phân tích (số thứ tự? độ dài? checksum?).
"""
import re, sys

def load_packets(path):
    pk = []
    for line in open(path, encoding="utf-8", errors="ignore"):
        h = re.sub(r"[^0-9A-Fa-f]", "", line)
        if len(h) >= 4 and len(h) % 2 == 0:
            b = bytes.fromhex(h)
            if b[0] == 0xD6:
                pk.append(b)
    return pk

def main():
    if len(sys.argv) != 3:
        print(__doc__); sys.exit(2)
    binf = open(sys.argv[1], "rb").read()
    pk = load_packets(sys.argv[2])
    if not pk:
        print("Không có gói D6 nào trong nhật ký."); sys.exit(1)
    lens = sorted(set(len(p) for p in pk))
    print(f"{len(pk)} gói D6, các độ dài gặp: {lens}; BIN = {len(binf)} byte")
    found = []
    for h in range(1, 13):
        for t in range(0, 5):
            if any(len(p) <= h + t for p in pk):
                continue
            data = b"".join(p[h:len(p) - t] for p in pk)
            if data == binf:
                found.append((h, t, "khớp TOÀN BỘ file"))
            elif len(data) <= len(binf) and binf.startswith(data) and len(data) > 0:
                found.append((h, t, f"khớp phần đầu ({len(data)}/{len(binf)} byte)"))
            elif len(data) >= len(binf) and data.startswith(binf):
                found.append((h, t, "dữ liệu dài hơn BIN (có byte thừa ở cuối)"))
    if found:
        for h, t, msg in found:
            print(f"KẾT QUẢ: header={h} byte, trailer={t} byte -> {msg}")
        full = [f for f in found if "TOÀN BỘ" in f[2]]
        if full:
            h, t, _ = full[0]
            print(f"Header (hex) từng gói đầu: {[p[:h].hex(' ') for p in pk[:5]]}")
            if h > 1 or t > 0:
                print("CẢNH BÁO: có header/trailer ngoài 'D6' => cần sửa D6Packetizer cho khớp (xem các byte trên: cố định, đếm tăng, hay checksum).")
            else:
                print("OK: gói = D6 + dữ liệu BIN thuần, đúng giả thuyết hiện tại của app.")
        return
    print("KHÔNG cấu hình header/trailer nào ghép lại đúng BIN. Có thể BIN được biến đổi/nén/mã hoá, hoặc log thiếu gói.")
    for i in list(range(min(5, len(pk)))) + [len(pk) - 1]:
        p = pk[i]
        print(f"gói {i}: len={len(p)} đầu={p[:12].hex(' ')} cuối={p[-6:].hex(' ')}")

if __name__ == "__main__":
    main()
