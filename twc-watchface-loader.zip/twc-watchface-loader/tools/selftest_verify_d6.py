import os, random, subprocess, sys, tempfile
here = os.path.dirname(os.path.abspath(__file__))
random.seed(1)
b = bytes(random.randrange(256) for _ in range(1000))
d = tempfile.mkdtemp()
open(f"{d}/t.bin", "wb").write(b)
with open(f"{d}/l.txt", "w") as f:
    for i in range(0, len(b), 237):
        f.write((b"\xd6" + b[i:i+237]).hex(" ") + "\n")
out = subprocess.run([sys.executable, f"{here}/verify_d6.py", f"{d}/t.bin", f"{d}/l.txt"], capture_output=True, text=True).stdout
assert "header=1 byte, trailer=0 byte -> khớp TOÀN BỘ file" in out, out
print("selftest verify_d6 OK")
