import com.twc.loader.core.*;
import java.util.*;

public class CoreTest {
    static int fails = 0, passes = 0;
    static void check(boolean c, String n) { if (c) passes++; else { fails++; System.out.println("FAIL: " + n); } }

    static final String D5 = "D5 05 01 01 00 00 00 06 00 FD 00 01 BB 30 CB";
    static final String R81 = "D5 05 01 81 00 00 00 06 00 EB 00 14 0A 14 7F";
    static final String R82 = "D5 05 01 82 00 00 00 00 5D";

    static class Env implements TransferController.Transport, TransferController.Scheduler, TransferController.Listener {
        StateMachine sm = new StateMachine();
        TransferController c = new TransferController(sm, this, this, this);
        List<String> tx = new ArrayList<>(), rx = new ArrayList<>(), msgs = new ArrayList<>();
        List<byte[]> txRaw = new ArrayList<>();
        List<Object[]> queue = new ArrayList<>();
        boolean rejectWrite; int lastPackets, totalPackets; long lastBytes;
        List<TransferState> hist = new ArrayList<>();
        Env() {
            sm.setListener(new StateMachine.Listener() {
                public void onState(TransferState f, TransferState t) { hist.add(t); }
                public void onIllegal(TransferState f, TransferState t) { msgs.add("ILLEGAL " + f + "->" + t); }
            });
            c.setDelayMs(200);
        }
        public boolean write(byte[] d) { if (rejectWrite) return false; txRaw.add(d); return true; }
        public void post(Runnable r, long ms) { queue.add(new Object[]{r, ms}); }
        public void onLog(boolean t, byte[] d) { (t ? tx : rx).add(HexUtil.toHex(d)); }
        public void onMessage(String m) { msgs.add(m); }
        public void onProgress(int p, int tp, long b, long tb) { lastPackets = p; totalPackets = tp; lastBytes = b; }
        void toReady() { for (TransferState s : new TransferState[]{TransferState.CONNECTING, TransferState.DISCOVERING, TransferState.ENABLING_NOTIFY, TransferState.READY}) sm.transition(s); }
        void runQueue() { while (!queue.isEmpty()) { Object[] o = queue.remove(0); if ((Long) o[1] != TransferController.WAIT_81_TIMEOUT_MS) ((Runnable) o[0]).run(); } }
        /** chạy tới khi hết gói D6 */
        void pump() { int guard = 0; while (guard++ < 100000) { if (c.pendingWrite()) { c.onWriteResult(true); } else if (!queue.isEmpty()) { Object[] o = queue.remove(0); if ((Long) o[1] != TransferController.WAIT_81_TIMEOUT_MS) ((Runnable) o[0]).run(); } else break; } }
    }

    static byte[] bin(int n) { byte[] b = new byte[n]; for (int i = 0; i < n; i++) b[i] = (byte) (i * 31 + 7); return b; }

    public static void main(String[] a) {
        // HEX
        check(Arrays.equals(HexUtil.parse(D5), new byte[]{(byte)0xD5,5,1,1,0,0,0,6,0,(byte)0xFD,0,1,(byte)0xBB,0x30,(byte)0xCB}), "parse D5");
        check(HexUtil.toHex(HexUtil.parse(D5)).equals(D5), "roundtrip");
        for (String bad : new String[]{"", "D", "ZZ", "D5 5", null}) { boolean t = false; try { HexUtil.parse(bad); } catch (IllegalArgumentException e) { t = true; } check(t, "bad hex " + bad); }
        // checksum 3 mẫu
        check(D5Frame.sum8(HexUtil.parse(D5), 14) == 0xCB, "sum D5");
        check(D5Frame.sum8(HexUtil.parse(R81), 14) == 0x7F, "sum 81");
        check(D5Frame.sum8(HexUtil.parse(R82), 8) == 0x5D, "sum 82");
        check(D5Frame.check(HexUtil.parse(R81), 0x81, true) == null, "81 ok");
        check(D5Frame.check(HexUtil.parse(R82), 0x82, true) == null, "82 ok");
        check(D5Frame.check(HexUtil.parse(R81), 0x82, true) != null, "81 not 82");
        check(D5Frame.check(HexUtil.parse("D5 05 01 81 00 00 00 06 00 EB 00 14 0A 14 7E"), 0x81, true) != null, "81 bad checksum");
        check(D5Frame.check(HexUtil.parse("D5 05 01 81 00 00 00 00 5C"), 0x81, true) != null, "81 strict length");
        check(D5Frame.check(HexUtil.parse("D5 05 01 81 00 00 00 00 5C"), 0x81, false) == null, "81 lenient length");
        check(D5Frame.check(HexUtil.parse("AA 05 01 81 00 00 00 00 5C"), 0x81, false) != null, "81 wrong head");
        check(D5Frame.check(HexUtil.parse("D5 05 01 81"), 0x81, true) != null, "81 too short");

        // Packetizer: nối lại == BIN, nhiều kích thước
        for (int n : new int[]{1, 236, 237, 238, 474, 475, 100000}) {
            byte[] b = bin(n); D6Packetizer p = new D6Packetizer(b, 238);
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); boolean hdr = true, lens = true;
            for (int i = 0; i < p.count(); i++) { byte[] q = p.packet(i); hdr &= (q[0] & 0xFF) == 0xD6; if (i < p.count() - 1) lens &= q.length == 238; else lens &= q.length <= 238; o.write(q, 1, q.length - 1); }
            check(hdr && lens && Arrays.equals(o.toByteArray(), b) && p.count() == (n + 236) / 237, "packetizer n=" + n);
        }
        boolean t = false; try { new D6Packetizer(new byte[0], 238); } catch (IllegalArgumentException e) { t = true; } check(t, "empty bin rejected");

        // State machine
        StateMachine s = new StateMachine(); check(!s.transition(TransferState.SENDING_D5), "DISCONNECTED->SENDING_D5 refused");
        check(!s.transition(TransferState.COMPLETE), "->COMPLETE refused");

        // Luồng đầy đủ
        {
            Env e = new Env(); e.toReady(); byte[] b = bin(1000);
            check(e.c.start(HexUtil.parse(D5), b, 238), "start");
            check(e.sm.get() == TransferState.SENDING_D5 && e.txRaw.size() == 1 && HexUtil.toHex(e.txRaw.get(0)).equals(D5), "D5 sent once, exact");
            e.c.onWriteResult(true);
            check(e.sm.get() == TransferState.WAIT_81, "WAIT_81");
            e.pump();
            check(e.txRaw.size() == 1, "no D6 before 81");
            e.c.onNotify(HexUtil.parse("D5 05 01 81 00 00 00 06 00 EB 00 14 0A 14 7E")); e.pump();
            check(e.txRaw.size() == 1 && e.sm.get() == TransferState.WAIT_81, "bad 81 ignored");
            e.c.onNotify(HexUtil.parse(R82)); e.pump();
            check(e.txRaw.size() == 1 && e.sm.get() == TransferState.WAIT_81, "82 in WAIT_81 ignored");
            e.c.onNotify(HexUtil.parse(R81));
            e.pump();
            check(e.txRaw.size() == 1 + 5, "5 D6 packets for 1000B (got " + (e.txRaw.size() - 1) + ")");
            check(e.sm.get() == TransferState.WAIT_82, "WAIT_82 after all sent");
            check(e.lastPackets == 5 && e.lastBytes == 1000, "progress final");
            check(e.msgs.contains("ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN."), "waiting message");
            check(e.sm.get() != TransferState.COMPLETE, "not COMPLETE before 82");
            e.c.onNotify(HexUtil.parse(R82));
            check(e.sm.get() == TransferState.COMPLETE && e.msgs.contains("TRUYỀN DỮ LIỆU HOÀN TẤT"), "COMPLETE on 82");
            // thứ tự và nội dung
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            for (int i = 1; i < e.txRaw.size(); i++) o.write(e.txRaw.get(i), 1, e.txRaw.get(i).length - 1);
            check(Arrays.equals(o.toByteArray(), b), "BIN order intact");
            check(e.rx.size() == 4 || e.rx.size() >= 3, "RX logged");
            check(!e.msgs.toString().contains("ILLEGAL"), "no illegal transitions: " + e.msgs);
            // delay mặc định giữa các gói
            // phiên mới sau COMPLETE
            e.sm.transition(TransferState.READY);
            check(e.c.start(HexUtil.parse(D5), b, 238) && e.txRaw.size() == 7 && HexUtil.toHex(e.txRaw.get(6)).equals(D5), "new session sends D5 again explicitly");
        }
        // 81 đến sớm trước callback ghi D5
        {
            Env e = new Env(); e.toReady(); e.c.start(HexUtil.parse(D5), bin(300), 238);
            e.c.onNotify(HexUtil.parse(R81));
            check(e.txRaw.size() == 1, "early 81 does not send before write cb");
            e.c.onWriteResult(true); e.pump();
            check(e.sm.get() == TransferState.WAIT_82 && e.txRaw.size() == 3, "early 81 handled after write cb");
        }
        // Pause / resume
        {
            Env e = new Env(); e.toReady(); byte[] b = bin(237 * 6); e.c.start(HexUtil.parse(D5), b, 238);
            e.c.onWriteResult(true); e.c.onNotify(HexUtil.parse(R81));
            e.c.onWriteResult(true); e.runQueue(); // gói 1 đang bay
            e.c.onWriteResult(true);               // xong gói 2? (kiểm tra bên dưới bằng số lượng)
            int sentBefore = e.txRaw.size();
            check(e.c.pause() && e.sm.get() == TransferState.PAUSED, "pause");
            e.runQueue(); e.pump();
            int sentAfterPause = e.txRaw.size();
            check(sentAfterPause <= sentBefore + 0 || sentAfterPause == sentBefore, "no new packet while paused");
            int pk = e.lastPackets;
            check(e.c.resume() && e.sm.get() == TransferState.SENDING_D6, "resume");
            e.pump();
            check(e.sm.get() == TransferState.WAIT_82 && e.lastPackets == 6, "finish after resume");
            check(e.txRaw.stream().filter(x -> HexUtil.toHex(x).equals(D5)).count() == 1, "D5 once only");
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            for (int i = 1; i < e.txRaw.size(); i++) o.write(e.txRaw.get(i), 1, e.txRaw.get(i).length - 1);
            check(Arrays.equals(o.toByteArray(), b), "no dup/skip across pause");
        }
        // Cancel
        {
            Env e = new Env(); e.toReady(); e.c.start(HexUtil.parse(D5), bin(5000), 238);
            e.c.onWriteResult(true); e.c.onNotify(HexUtil.parse(R81)); e.c.cancel();
            int n = e.txRaw.size(); e.c.onWriteResult(true); e.runQueue();
            check(e.sm.get() == TransferState.CANCELLED && e.txRaw.size() == n, "cancel stops sending");
            e.c.onNotify(HexUtil.parse(R82)); check(e.sm.get() == TransferState.CANCELLED, "82 after cancel ignored");
        }
        // Mất kết nối / lỗi ghi / từ chối ghi / start sai trạng thái
        {
            Env e = new Env(); e.toReady(); e.c.start(HexUtil.parse(D5), bin(5000), 238);
            e.c.onWriteResult(true); e.c.onNotify(HexUtil.parse(R81)); e.c.onDisconnected();
            int n = e.txRaw.size(); e.runQueue();
            check(e.sm.get() == TransferState.DISCONNECTED && e.txRaw.size() == n, "disconnect stops");
            Env f = new Env(); f.toReady(); f.c.start(HexUtil.parse(D5), bin(10), 238); f.c.onWriteResult(false);
            check(f.sm.get() == TransferState.ERROR, "write error -> ERROR");
            Env g = new Env(); g.toReady(); g.rejectWrite = true;
            check(!g.c.start(HexUtil.parse(D5), bin(10), 238) && g.sm.get() == TransferState.ERROR, "rejected write -> ERROR");
            Env h = new Env(); check(!h.c.start(HexUtil.parse(D5), bin(10), 238) && h.txRaw.isEmpty(), "no start when not READY");
            Env i = new Env(); i.toReady(); check(!i.c.start(HexUtil.parse(D5), new byte[0], 238) && i.txRaw.isEmpty(), "no start on empty file");
        }
        // Chờ 81 hết hạn
        {
            Env e = new Env(); e.toReady(); e.c.start(HexUtil.parse(D5), bin(10), 238); e.c.onWriteResult(true);
            for (Object[] o : e.queue) if ((Long) o[1] == TransferController.WAIT_81_TIMEOUT_MS) ((Runnable) o[0]).run();
            check(e.sm.get() == TransferState.ERROR, "81 timeout -> ERROR");
        }
        System.out.println("PASS=" + passes + " FAIL=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
