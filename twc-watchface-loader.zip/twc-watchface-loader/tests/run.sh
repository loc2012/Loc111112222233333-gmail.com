#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
if command -v javac >/dev/null 2>&1; then JAVAC="javac"; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JAVAC -encoding UTF-8 -d "$OUT" app/src/main/java/com/twc/loader/core/*.java tests/CoreTest.java
java -cp "$OUT" CoreTest
