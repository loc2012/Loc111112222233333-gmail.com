# TWC Watchface Loader (Android, Java, không phụ thuộc AndroidX)

Truyền file BIN mặt đồng hồ sang đồng hồ TWC (HryFine Max) qua BLE, chỉ dùng service **FF00**: Notify **FF01**, ghi **FF02**.
Quy trình tự động sau một lần bấm BẮT ĐẦU: `D5 → chờ 81 → D6 từng gói → chờ 82 → HOÀN TẤT`.

## Lấy APK (không cần cài Android Studio)
1. Tạo repo GitHub mới, tải toàn bộ thư mục này lên (giữ nguyên thư mục `.github`).
2. Vào tab **Actions** → workflow **Build APK** (tự chạy khi push; hoặc bấm *Run workflow*).
3. Khi xong, mở lần chạy → mục **Artifacts** → tải `TWC-Watchface-Loader-debug-apk` → giải nén ra `app-debug.apk`.
4. Cài lên điện thoại Android 12–14 (cho phép cài từ nguồn không rõ).
Nếu build lỗi, gửi lại log của bước *Build APK debug*.

Hoặc dùng Android Studio: *Open* thư mục này → Sync → *Build > Build APK(s)*.

## Sử dụng
1. Cấp quyền "Thiết bị ở gần" → QUÉT ĐỒNG HỒ → chọn đồng hồ → KẾT NỐI. Chờ FF01 "Notify BẬT", trạng thái READY.
2. (Tuỳ chọn) sửa MÃ D5 → LƯU MÃ. Mã được gửi đúng như đã lưu, không tự sửa byte.
3. CHỌN FILE BIN → chọn khoảng nghỉ (mặc định 200 ms) → BẮT ĐẦU. Giữ màn hình sáng, app ở phía trước.
4. Chỉ khi nhận 82 hợp lệ mới hiện "TRUYỀN DỮ LIỆU HOÀN TẤT". XUẤT TXT để lấy nhật ký HEX đầy đủ.
Mất kết nối = dừng hẳn; phải bắt đầu phiên mới (gửi lại D5 từ đầu), app không tự tiếp tục.

## Đã xác minh / chưa xác minh
**Đã kiểm tra bằng chương trình (60 kiểm thử, `tests/run.sh`):** phân tích HEX, state machine, thứ tự D5→81→D6→82, không gửi D6 khi chưa có 81, không báo COMPLETE khi chưa có 82, tạm dừng/tiếp tục/hủy không mất/lặp gói, mất kết nối, lỗi ghi, hết hạn chờ 81, BIN ghép lại đúng thứ tự.

**Suy ra từ 3 mẫu bạn đưa (khớp cả 3):** gói D5 = `D5 05 01 <lệnh> 00 00 00 <N> <N byte payload> <checksum>`, checksum = tổng 8-bit mod 256 của mọi byte phía trước (CB, 7F, 5D). Mặc định app yêu cầu 81 dài 15 byte, 82 dài 9 byte như mẫu, đúng cấu trúc và đúng checksum; có tuỳ chọn nới độ dài.

**CHƯA xác minh – quan trọng:** cấu trúc gói D6. App đang dùng giả thuyết `D6 + 237 byte BIN liên tiếp` (không header/checksum thêm). Hãy xác minh bằng nhật ký cũ trước khi tin:
`python3 tools/verify_d6.py file.bin nhat_ky_d6.txt` (mỗi gói ATT một dòng HEX). Script báo chính xác header/trailer nào ghép lại ra đúng file BIN. Nếu có byte đếm/độ dài/checksum, cần sửa `core/D6Packetizer.java`.

**Chưa chạy trên đồng hồ thật / chưa biên dịch Android ở môi trường tạo ra gói này** (không có Android SDK/mạng): lớp BLE và giao diện chưa được build; việc build được kiểm bằng GitHub Actions.
