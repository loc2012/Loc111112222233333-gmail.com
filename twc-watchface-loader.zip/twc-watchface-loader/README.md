# TWC Watchface Loader (Android, BLE)

Gửi file BIN mặt đồng hồ sang smartwatch TWC (HryFine Max) qua BLE theo trình tự:
**kết nối → bật Notify FF01 → gửi D5 → chờ 81 → tự gửi D6 → chờ 82 → hoàn tất.**

Chỉ dùng Service `FF00`, characteristic `FF01` (Notify) và `FF02` (Write).

## Build APK

**Cách 1 – GitHub Actions (không cần cài gì):** đẩy code lên GitHub → tab *Actions* → *Build APK* →
tải artifact `TWC-Watchface-Loader-debug-apk` (file `app-debug.apk`).

**Cách 2 – Android Studio:** mở thư mục dự án (Giraffe trở lên, JDK 17) → *Build > Build APK(s)*.
Gradle Wrapper chưa kèm theo (xem ghi chú); Android Studio dùng Gradle 8.7, hoặc chạy `gradle wrapper --gradle-version 8.7` để tạo wrapper rồi commit.

## Cách dùng
1. Cấp quyền Bluetooth → QUÉT ĐỒNG HỒ → chọn đồng hồ → KẾT NỐI (đợi FF01 "Notify ĐÃ BẬT").
2. (Tùy chọn) sửa mã D5 → LƯU MÃ. Chọn khoảng nghỉ (mặc định 200 ms).
3. CHỌN FILE BIN → BẮT ĐẦU (một lần duy nhất). Có TẠM DỪNG / TIẾP TỤC / HỦY.
4. Chỉ khi hiện **TRUYỀN DỮ LIỆU HOÀN TẤT** (đã nhận 82) mới là thành công.
5. XUẤT NHẬT KÝ TXT để gửi lại phân tích.

## Phân loại thông tin giao thức
**Đã quan sát (theo tài liệu yêu cầu):** Service FF00; FF01 notify; FF02 write; D5 → 81 → D6 → 82;
gói D6 thường có ATT value 238 byte.

**CHƯA XÁC MINH – đang là giả thuyết (nằm trong `D6Packer` ở `Protocol.kt`):**
- Mỗi gói D6 = `D6` + 237 byte BIN nguyên bản, gói cuối ngắn hơn; không thêm trường điều khiển/checksum/gói kết thúc.
- Phản hồi 81/82 chỉ được chấp nhận khi **khớp 100%** mẫu đã quan sát (nếu đúng độ dài + tiền tố nhưng khác mẫu thì bị từ chối và ghi log).
  Nếu phiên thật có trường biến đổi (VD: checksum/độ dài), cần sửa `Protocol.match`.

**Cần để xác minh:** một nhật ký Bluetooth HCI (btsnoop) của app gốc truyền *một file BIN nhỏ đã biết*,
kèm chính file BIN đó. So sánh payload các gói D6 với file để xác định: có header/đếm gói/checksum không, gói cuối có quy tắc riêng không.

## Ghi chú
- minSdk 31 (Android 12) – target 34. Không cần quyền vị trí/bộ nhớ (dùng Storage Access Framework).
- Mất kết nối giữa chừng → ERROR, không tự nối tiếp; phải kết nối lại và bắt đầu phiên mới.
- Ưu tiên WRITE có response; chỉ dùng WRITE NO RESPONSE nếu FF02 không hỗ trợ WRITE. Gửi từng gói, chờ callback + khoảng nghỉ.
- Mã nguồn **chưa được biên dịch/chạy thử trên thiết bị thật** khi tạo (môi trường không có Android SDK/mạng).
