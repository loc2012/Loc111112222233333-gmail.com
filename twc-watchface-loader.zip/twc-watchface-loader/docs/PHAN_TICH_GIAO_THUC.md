# Phân tích khung D5 (từ 7 gói đã có)

Khung: `D5 05 01 <CMD> | LEN(4 byte BE) | PAYLOAD(LEN byte) | SUM8`
SUM8 = tổng mod 256 của mọi byte đứng trước nó (kể cả D5 và trường LEN).

| Gói | LEN | SUM8 tính ra | Byte cuối thật |
|---|---|---|---|
| D5 01 (lời chào) | 6 | CB | CB ✓ |
| 81 mẫu A | 6 | A8 | A8 ✓ |
| 81 mẫu B | 6 | 7F | 7F ✓ |
| 82 | 0 | 5D | 5D ✓ (gói 82 luôn cố định) |
| D5 02 (B3 91) | 1 | 91 | 91 ✓ |
| D5 02 (25 03) | 1 | 03 | 03 ✓ |
| D5 02 (1C FA) | 1 | FA | FA ✓ |

=> Với D5 02: byte `xx` (B3 / 25 / 1C) là PAYLOAD 1 byte, byte `yy` (91 / 03 / FA) là SUM8. **Đã xác minh.**

**CHƯA xác minh:** `xx` được tạo từ đâu (chưa thể biết nếu không có dữ liệu D6 của từng nhóm).
Ứng viên cần thử (KHÔNG áp dụng): tổng/XOR/CRC8 của dữ liệu nhóm, số thứ tự nhóm, v.v.

Quan sát chưa kết luận: trong 81 mẫu B có byte 0xEB (=235, đúng bằng độ dài ATT D6) và byte 0x0A (=10, đúng bằng số gói/nhóm). Mẫu A có 0x14 ở vị trí tương ứng. Có thể 81 báo kích thước gói/nhóm, nhưng chưa có bằng chứng.

**Cần để chốt:** file btsnoop_hci.log gốc + đúng file BIN đã được truyền trong log đó.
