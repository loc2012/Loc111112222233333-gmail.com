package com.twc.watchfaceloader

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HexLog {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val lines = ArrayList<String>()
    var onChange: (() -> Unit)? = null

    fun tx(ch: String, b: ByteArray) = add("TX $ch [${b.size} byte]:\n${HexUtil.toHex(b)}")
    fun rx(ch: String, b: ByteArray) = add("RX $ch [${b.size} byte]:\n${HexUtil.toHex(b)}")
    fun info(s: String) = add("-- $s")

    @Synchronized private fun add(s: String) {
        lines.add("${fmt.format(Date())} $s")
        onChange?.invoke()
    }

    @Synchronized fun full(): String = lines.joinToString("\n")

    /** Chỉ phần cuối để hiển thị cho nhẹ; file xuất ra là bản đầy đủ. */
    @Synchronized fun tail(n: Int = 60): String = lines.takeLast(n).joinToString("\n")

    @Synchronized fun clear() { lines.clear(); onChange?.invoke() }
}
