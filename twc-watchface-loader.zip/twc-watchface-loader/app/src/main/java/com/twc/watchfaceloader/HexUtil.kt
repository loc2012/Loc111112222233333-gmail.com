package com.twc.watchfaceloader

object HexUtil {
    fun toHex(b: ByteArray): String =
        b.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    /** Trả về null nếu sai định dạng. Không sửa, không thêm, không bỏ byte. */
    fun parse(s: String): ByteArray? {
        val c = s.filter { !it.isWhitespace() }
        if (c.isEmpty() || c.length % 2 != 0) return null
        if (!c.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        return ByteArray(c.length / 2) { c.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }
}
