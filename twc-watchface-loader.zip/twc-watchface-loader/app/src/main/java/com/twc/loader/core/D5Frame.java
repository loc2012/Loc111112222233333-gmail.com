package com.twc.loader.core;

/**
 * Khung D5 (suy ra từ 3 mẫu đã quan sát: D5 cmd 01/81/82):
 *  [0]=D5 [1]=05 [2]=01 [3]=cmd [4..6]=00 00 00 [7]=độ dài payload N, [8..8+N-1]=payload, [cuối]=tổng 8-bit (mod 256) của mọi byte phía trước.
 * Quy tắc "byte cuối = tổng các byte trước" đã được kiểm chứng khớp cả 3 mẫu (CB, 7F, 5D).
 */
public final class D5Frame {
    private D5Frame() {}

    public static int sum8(byte[] p, int len) {
        int s = 0;
        for (int i = 0; i < len; i++) s += p[i] & 0xFF;
        return s & 0xFF;
    }

    /** Trả về null nếu hợp lệ, ngược lại là lý do lỗi. */
    public static String check(byte[] p, int expectedCmd, boolean strictLength) {
        if (p == null || p.length < 9) return "độ dài < 9";
        if ((p[0] & 0xFF) != 0xD5) return "byte0 != D5";
        if (p[1] != 0x05) return "byte1 != 05";
        if (p[2] != 0x01) return "byte2 != 01";
        if ((p[3] & 0xFF) != expectedCmd) return "mã lệnh != " + String.format("%02X", expectedCmd);
        if (p[4] != 0 || p[5] != 0 || p[6] != 0) return "byte4..6 != 00";
        if ((p[7] & 0xFF) != p.length - 9) return "trường độ dài payload không khớp";
        if ((p[p.length - 1] & 0xFF) != sum8(p, p.length - 1)) return "checksum sai";
        if (strictLength) {
            int want = expectedCmd == 0x81 ? 15 : expectedCmd == 0x82 ? 9 : -1;
            if (want > 0 && p.length != want) return "độ dài " + p.length + " != " + want + " (mẫu đã quan sát)";
        }
        return null;
    }
}
