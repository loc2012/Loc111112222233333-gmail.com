package com.twc.watchfaceloader

import java.util.UUID

object Protocol {
    private fun u16(s: String) = UUID.fromString("0000$s-0000-1000-8000-00805f9b34fb")
    val SERVICE_FF00: UUID = u16("ff00")
    val CHAR_FF01: UUID = u16("ff01")   // Notify (RX)
    val CHAR_FF02: UUID = u16("ff02")   // Write  (TX)
    val CCCD: UUID = u16("2902")

    const val DEFAULT_D5 = "D5 05 01 01 00 00 00 06 00 FD 00 01 BB 30 CB"

    /** Mẫu đã quan sát trong nhật ký. */
    val EXPECTED_81: ByteArray = HexUtil.parse("D5 05 01 81 00 00 00 06 00 14 00 14 0A 14 A8")!!
    val EXPECTED_82: ByteArray = HexUtil.parse("D5 05 01 82 00 00 00 00 5D")!!

    /** Độ dài ATT value của mỗi gói D6 (đã quan sát: 238, gói cuối có thể ngắn hơn). */
    const val D6_ATT_LEN = 238
    const val MTU_REQUEST = 247

    enum class Match { OK, STRUCT_ONLY, NO }

    /**
     * Kiểm tra phản hồi D5 05 01 <code>:
     *  OK          = khớp 100% gói mẫu (độ dài + toàn bộ byte)
     *  STRUCT_ONLY = đúng độ dài và tiền tố D5 05 01 <code> nhưng khác mẫu -> KHÔNG được chấp nhận
     *  NO          = không phải phản hồi này
     */
    fun match(data: ByteArray, code: Int, expected: ByteArray): Match {
        if (data.size != expected.size) return Match.NO
        if (data[0] != 0xD5.toByte() || data[1] != 0x05.toByte() ||
            data[2] != 0x01.toByte() || data[3] != code.toByte()) return Match.NO
        return if (data.contentEquals(expected)) Match.OK else Match.STRUCT_ONLY
    }
}

/**
 * Đóng gói D6 — TOÀN BỘ giả thuyết nằm ở đây, dễ sửa khi có nhật ký xác minh.
 *
 * GIẢ THUYẾT HIỆN TẠI (CHƯA XÁC MINH): mỗi gói = 0xD6 + tối đa 237 byte BIN nguyên bản,
 * liên tiếp, đúng thứ tự, không thêm checksum/header/gói kết thúc.
 */
object D6Packer {
    const val HEADER: Byte = 0xD6.toByte()

    fun split(bin: ByteArray, attLen: Int = Protocol.D6_ATT_LEN): List<ByteArray> {
        val chunk = attLen - 1
        val out = ArrayList<ByteArray>((bin.size + chunk - 1) / chunk)
        var off = 0
        while (off < bin.size) {
            val n = minOf(chunk, bin.size - off)
            val p = ByteArray(n + 1)
            p[0] = HEADER
            System.arraycopy(bin, off, p, 1, n)
            out.add(p)
            off += n
        }
        return out
    }
}
