package com.twc.loader.core;

/** Tiện ích HEX. Không tự sửa, không tự thêm/bớt byte. */
public final class HexUtil {
    private HexUtil() {}

    /** Phân tích chuỗi HEX (cho phép khoảng trắng). Ném IllegalArgumentException nếu sai định dạng. */
    public static byte[] parse(String s) {
        if (s == null) throw new IllegalArgumentException("HEX rỗng");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') continue;
            if (Character.digit(c, 16) < 0) throw new IllegalArgumentException("Ký tự không phải HEX: '" + c + "'");
            sb.append(c);
        }
        if (sb.length() == 0) throw new IllegalArgumentException("HEX rỗng");
        if (sb.length() % 2 != 0) throw new IllegalArgumentException("Số ký tự HEX lẻ");
        byte[] out = new byte[sb.length() / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte) ((Character.digit(sb.charAt(2 * i), 16) << 4) | Character.digit(sb.charAt(2 * i + 1), 16));
        }
        return out;
    }

    public static String toHex(byte[] b) { return toHex(b, 0, b.length); }

    public static String toHex(byte[] b, int off, int len) {
        StringBuilder sb = new StringBuilder(len * 3);
        for (int i = off; i < off + len; i++) {
            if (i > off) sb.append(' ');
            sb.append(Character.toUpperCase(Character.forDigit((b[i] >> 4) & 0xF, 16)));
            sb.append(Character.toUpperCase(Character.forDigit(b[i] & 0xF, 16)));
        }
        return sb.toString();
    }
}
