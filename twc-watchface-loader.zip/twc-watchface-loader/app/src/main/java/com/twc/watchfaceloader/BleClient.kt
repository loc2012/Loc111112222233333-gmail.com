package com.twc.watchfaceloader

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper

/** Chỉ làm việc với Service FF00, FF01 (notify), FF02 (write). Mọi callback chạy trên luồng chính. */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleClient(private val ctx: Context) {
    private val h = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        ctx.getSystemService(BluetoothManager::class.java)?.adapter

    var onScanResult: ((BluetoothDevice, Int) -> Unit)? = null
    var onScanStopped: (() -> Unit)? = null
    var onStage: ((State, String) -> Unit)? = null
    var onChars: ((String, String) -> Unit)? = null       // trạng thái FF01, FF02
    var onFail: ((String) -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onNotify: ((ByteArray) -> Unit)? = null
    var onWriteDone: ((Boolean) -> Unit)? = null
    var onInfo: ((String) -> Unit)? = null

    private var gatt: BluetoothGatt? = null
    private var ff01: BluetoothGattCharacteristic? = null
    private var ff02: BluetoothGattCharacteristic? = null
    private var scanning = false

    @Volatile var ready = false; private set
    var mtu = 23; private set
    val attPayload get() = mtu - 3

    // ---------- quét ----------
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            h.post { this@BleClient.onScanResult?.invoke(r.device, r.rssi) }
        }
        override fun onScanFailed(errorCode: Int) {
            h.post { stopScan(); onFail?.invoke("Quét thất bại, mã lỗi $errorCode") }
        }
    }
    private val stopRunnable = Runnable { stopScan() }

    fun isEnabled() = adapter?.isEnabled == true

    fun startScan() {
        val sc = adapter?.bluetoothLeScanner ?: run { onFail?.invoke("Bluetooth chưa bật"); return }
        if (scanning) return
        scanning = true
        sc.startScan(scanCb)
        h.postDelayed(stopRunnable, 12_000)
        onStage?.invoke(State.SCANNING, "Đang quét...")
    }

    fun stopScan() {
        h.removeCallbacks(stopRunnable)
        if (!scanning) return
        scanning = false
        try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        onScanStopped?.invoke()
    }

    // ---------- kết nối ----------
    fun connect(dev: BluetoothDevice) {
        stopScan()
        close()
        onStage?.invoke(State.CONNECTING, "Đang kết nối ${dev.address}")
        onChars?.invoke("FF01: chưa kiểm tra", "FF02: chưa kiểm tra")
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() { gatt?.disconnect() }

    fun close() {
        ready = false
        ff01 = null; ff02 = null
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
    }

    private fun fail(msg: String) {
        ready = false
        onFail?.invoke(msg)
        gatt?.disconnect()
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            h.post {
                if (g !== gatt) return@post
                if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                    onStage?.invoke(State.DISCOVERING, "Đã kết nối, yêu cầu MTU ${Protocol.MTU_REQUEST}")
                    if (!g.requestMtu(Protocol.MTU_REQUEST)) g.discoverServices()
                } else {
                    val wasReady = ready
                    ready = false
                    onInfo?.invoke("Ngắt kết nối (status=$status, wasReady=$wasReady)")
                    close()
                    onDisconnected?.invoke()
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            h.post {
                if (g !== gatt) return@post
                mtu = m
                onInfo?.invoke("MTU=$m (status=$status), ATT payload tối đa=${m - 3}")
                g.discoverServices()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            h.post {
                if (g !== gatt) return@post
                if (status != BluetoothGatt.GATT_SUCCESS) { fail("Tìm service thất bại ($status)"); return@post }
                val svc = g.getService(Protocol.SERVICE_FF00)
                if (svc == null) {
                    onInfo?.invoke("Service có sẵn: " + g.services.joinToString { it.uuid.toString() })
                    onChars?.invoke("FF01: không có", "FF02: không có")
                    fail("Không tìm thấy Service FF00"); return@post
                }
                ff01 = svc.getCharacteristic(Protocol.CHAR_FF01)
                ff02 = svc.getCharacteristic(Protocol.CHAR_FF02)
                val p1 = ff01?.properties ?: 0
                val p2 = ff02?.properties ?: 0
                val canNotify = (p1 and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                val canWrite = (p2 and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0
                val canWriteNr = (p2 and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                onChars?.invoke(
                    if (ff01 == null) "FF01: KHÔNG TÌM THẤY" else "FF01: có, props=0x${p1.toString(16)} notify=$canNotify",
                    if (ff02 == null) "FF02: KHÔNG TÌM THẤY" else "FF02: có, props=0x${p2.toString(16)} write=$canWrite writeNoResp=$canWriteNr"
                )
                if (ff01 == null) { fail("Không tìm thấy FF01"); return@post }
                if (ff02 == null) { fail("Không tìm thấy FF02"); return@post }
                if (!canNotify) { fail("FF01 không hỗ trợ Notify"); return@post }
                if (!canWrite && !canWriteNr) { fail("FF02 không cho phép ghi"); return@post }
                // Ưu tiên WRITE có response (có xác nhận từ đồng hồ), nếu không có mới dùng WRITE NO RESPONSE
                ff02!!.writeType = if (canWrite) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                                   else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                onInfo?.invoke("Kiểu ghi FF02: " + if (canWrite) "WRITE (có response)" else "WRITE NO RESPONSE")

                onStage?.invoke(State.ENABLING_NOTIFY, "Bật Notify FF01")
                if (!g.setCharacteristicNotification(ff01, true)) { fail("setCharacteristicNotification thất bại"); return@post }
                val d = ff01!!.getDescriptor(Protocol.CCCD)
                if (d == null) { fail("FF01 không có CCCD 2902"); return@post }
                d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                if (!g.writeDescriptor(d)) fail("Ghi CCCD thất bại")
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            h.post {
                if (g !== gatt || d.uuid != Protocol.CCCD || d.characteristic.uuid != Protocol.CHAR_FF01) return@post
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    ready = true
                    onChars?.invoke(
                        "FF01: Notify ĐÃ BẬT",
                        "FF02: sẵn sàng ghi (" +
                            (if (ff02!!.writeType == BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) "WRITE" else "WRITE NO RESPONSE") + ")"
                    )
                    onStage?.invoke(State.READY, "Sẵn sàng")
                } else fail("Bật Notify FF01 thất bại ($status)")
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            h.post {
                if (g !== gatt || c.uuid != Protocol.CHAR_FF02) return@post
                onWriteDone?.invoke(status == BluetoothGatt.GATT_SUCCESS)
            }
        }

        // Android < 13
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return
            val v = c.value?.copyOf() ?: return
            h.post { if (g === gatt && c.uuid == Protocol.CHAR_FF01) onNotify?.invoke(v) }
        }

        // Android 13+
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            val v = value.copyOf()
            h.post { if (g === gatt && c.uuid == Protocol.CHAR_FF01) onNotify?.invoke(v) }
        }
    }

    // ---------- ghi: duy nhất qua FF02 ----------
    fun write(data: ByteArray): Boolean {
        val g = gatt ?: return false
        val c = ff02 ?: return false
        if (!ready) return false
        c.value = data
        return g.writeCharacteristic(c)
    }
}
