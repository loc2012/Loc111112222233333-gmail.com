package com.twc.watchfaceloader

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var ble: BleClient
    private lateinit var engine: TransferEngine
    private val log = HexLog()

    private val devices = LinkedHashMap<String, BluetoothDevice>()
    private var selected: BluetoothDevice? = null
    private var bin: ByteArray? = null
    private val intervals = listOf(20L, 50L, 100L, 200L)

    private lateinit var btnScan: Button
    private lateinit var btnConnect: Button
    private lateinit var btnStart: Button
    private lateinit var btnPause: Button
    private lateinit var btnResume: Button
    private lateinit var btnCancel: Button
    private lateinit var rg: RadioGroup
    private lateinit var tvConn: TextView
    private lateinit var tvFf01: TextView
    private lateinit var tvFf02: TextView
    private lateinit var tvFile: TextView
    private lateinit var tvSize: TextView
    private lateinit var tvProg: TextView
    private lateinit var tvResult: TextView
    private lateinit var tvLog: TextView
    private lateinit var svLog: ScrollView
    private lateinit var pb: ProgressBar
    private lateinit var etD5: EditText
    private lateinit var spInterval: Spinner

    private val prefs by lazy { getSharedPreferences("twc", Context.MODE_PRIVATE) }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) toast("Đã cấp quyền Bluetooth") else toast("Cần cấp quyền Bluetooth để quét/kết nối")
    }
    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadBin(uri)
    }
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try {
            contentResolver.openOutputStream(uri)?.use { it.write(log.full().toByteArray()) }
            toast("Đã xuất nhật ký")
        } catch (e: Exception) { toast("Xuất thất bại: ${e.message}") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnScan = findViewById(R.id.btnScan); btnConnect = findViewById(R.id.btnConnect)
        btnStart = findViewById(R.id.btnStart); btnPause = findViewById(R.id.btnPause)
        btnResume = findViewById(R.id.btnResume); btnCancel = findViewById(R.id.btnCancel)
        rg = findViewById(R.id.rgDevices); tvConn = findViewById(R.id.tvConn)
        tvFf01 = findViewById(R.id.tvFf01); tvFf02 = findViewById(R.id.tvFf02)
        tvFile = findViewById(R.id.tvFile); tvSize = findViewById(R.id.tvSize)
        tvProg = findViewById(R.id.tvProg); tvResult = findViewById(R.id.tvResult)
        tvLog = findViewById(R.id.tvLog); svLog = findViewById(R.id.svLog)
        pb = findViewById(R.id.pb); etD5 = findViewById(R.id.etD5)
        spInterval = findViewById(R.id.spInterval)

        spInterval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            intervals.map { "$it ms" + if (it == 200L) " (chậm, ổn định – mặc định)" else "" })
        spInterval.setSelection(intervals.indexOf(prefs.getLong("interval", 200L)).coerceAtLeast(0))
        spInterval.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putLong("interval", intervals[pos]).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        etD5.setText(prefs.getString("d5", Protocol.DEFAULT_D5))

        ble = BleClient(this)
        engine = TransferEngine(ble, log)

        log.onChange = { runOnUiThread { tvLog.text = log.tail(); svLog.post { svLog.fullScroll(View.FOCUS_DOWN) } } }

        ble.onInfo = { log.info(it) }
        ble.onStage = { s, m -> engine.setState(s, m) }
        ble.onChars = { a, b -> tvFf01.text = a; tvFf02.text = b }
        ble.onFail = { engine.fail(it) }
        ble.onDisconnected = { engine.onDisconnected() }
        ble.onNotify = { engine.onRx(it) }
        ble.onWriteDone = { engine.onWriteDone(it) }
        ble.onScanResult = { d, rssi -> addDevice(d, rssi) }
        ble.onScanStopped = { if (engine.state == State.SCANNING) engine.setState(State.DISCONNECTED, "Dừng quét") }

        engine.onState = { s, m -> onStateChanged(s, m) }
        engine.onProgress = { p -> showProgress(p) }

        btnScan.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            if (!ble.isEnabled()) { toast("Hãy bật Bluetooth"); return@setOnClickListener }
            rg.removeAllViews(); devices.clear(); selected = null
            ble.startScan()
        }
        btnConnect.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            if (ble.ready || engine.state in setOf(State.CONNECTING, State.DISCOVERING, State.ENABLING_NOTIFY)) {
                engine.cancel(); ble.disconnect()
            } else {
                val d = selected ?: run { toast("Chọn một thiết bị trong danh sách"); return@setOnClickListener }
                ble.connect(d)
            }
        }
        findViewById<Button>(R.id.btnSaveD5).setOnClickListener {
            val t = etD5.text.toString()
            if (HexUtil.parse(t) == null) toast("HEX không hợp lệ – chưa lưu")
            else { prefs.edit().putString("d5", t).apply(); toast("Đã lưu mã D5") }
        }
        findViewById<Button>(R.id.btnResetD5).setOnClickListener {
            etD5.setText(Protocol.DEFAULT_D5); prefs.edit().putString("d5", Protocol.DEFAULT_D5).apply()
            toast("Đã khôi phục mặc định")
        }
        findViewById<Button>(R.id.btnPick).setOnClickListener {
            if (engine.busy) toast("Đang truyền, không đổi file") else pickLauncher.launch(arrayOf("*/*"))
        }
        btnStart.setOnClickListener { startTransfer() }
        btnPause.setOnClickListener { engine.pause() }
        btnResume.setOnClickListener { engine.resume() }
        btnCancel.setOnClickListener { engine.cancel() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportLauncher.launch("twc_log.txt") }
        findViewById<Button>(R.id.btnClearLog).setOnClickListener { log.clear() }

        refresh()
    }

    private fun startTransfer() {
        val saved = prefs.getString("d5", Protocol.DEFAULT_D5) ?: Protocol.DEFAULT_D5
        val d5 = HexUtil.parse(saved) ?: run { toast("Mã D5 đã lưu không hợp lệ"); return }
        if (etD5.text.toString() != saved) toast("Khung D5 có nội dung chưa lưu – đang dùng mã ĐÃ LƯU")
        val b = bin ?: run { toast("Chưa chọn file BIN"); return }
        tvResult.text = ""
        val err = engine.start(d5, b, intervals[spInterval.selectedItemPosition])
        if (err != null) toast(err)
    }

    private fun loadBin(uri: Uri) {
        try {
            var name = "(không rõ)"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) name = c.getString(i)
            }
            val data = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
            if (data.isEmpty()) { toast("File rỗng hoặc không đọc được"); bin = null }
            else bin = data
            tvFile.text = "Tên file: $name"
            tvSize.text = "Dung lượng: ${data.size} byte"
            log.info("Đã chọn BIN: $name (${data.size} byte)")
        } catch (e: Exception) { bin = null; toast("Không đọc được file: ${e.message}") }
        refresh()
    }

    private fun addDevice(d: BluetoothDevice, rssi: Int) {
        if (devices.containsKey(d.address)) return
        devices[d.address] = d
        val name = try { d.name } catch (_: SecurityException) { null } ?: "(không tên)"
        val rb = RadioButton(this).apply {
            id = View.generateViewId(); text = "$name\n${d.address}  RSSI $rssi"
            setOnClickListener { selected = d; refresh() }
        }
        rg.addView(rb)
    }

    private fun onStateChanged(s: State, msg: String) {
        tvConn.text = "Trạng thái: $s" + if (msg.isNotEmpty()) " – $msg" else ""
        when (s) {
            State.COMPLETE -> tvResult.text = "TRUYỀN DỮ LIỆU HOÀN TẤT"
            State.WAIT_82 -> tvResult.text = "ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN."
            State.CANCELLED -> tvResult.text = "CANCELLED"
            State.ERROR -> tvResult.text = "LỖI: $msg"
            else -> {}
        }
        if (engine.busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refresh()
    }

    private fun showProgress(p: TransferEngine.Progress) {
        pb.progress = if (p.total > 0) (p.sent * 1000 / p.total).toInt() else 0
        val pct = if (p.total > 0) p.sent * 100.0 / p.total else 0.0
        tvProg.text = "%d / %d byte (%.1f%%)\nGói: %d / %d (còn %d)\nTốc độ: %d B/s".format(
            p.sent, p.total, pct, p.pkts, p.totalPkts, p.totalPkts - p.pkts, p.bps)
    }

    private fun refresh() {
        val s = engine.state
        val connecting = s in setOf(State.CONNECTING, State.DISCOVERING, State.ENABLING_NOTIFY)
        btnScan.isEnabled = !ble.ready && !connecting && !engine.busy && s != State.SCANNING
        btnConnect.text = if (ble.ready || connecting) "NGẮT KẾT NỐI" else "KẾT NỐI"
        btnConnect.isEnabled = ble.ready || connecting || selected != null
        btnStart.isEnabled = ble.ready && !engine.busy && bin != null
        btnPause.isEnabled = s == State.SENDING_D6
        btnResume.isEnabled = s == State.PAUSED
        btnCancel.isEnabled = engine.busy
    }

    private fun perms() = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    private fun hasPerms() = perms().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    private fun askPerms() = permLauncher.launch(perms())
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        engine.shutdown()
        ble.stopScan()
        ble.close()
        super.onDestroy()
    }
}
