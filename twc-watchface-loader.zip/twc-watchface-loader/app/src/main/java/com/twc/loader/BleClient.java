package com.twc.loader;

import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.UUID;

/** BLE: chỉ dùng service FF00, FF01 (Notify), FF02 (Write). Mọi callback được chuyển về luồng chính. */
@SuppressLint({"MissingPermission"})
@SuppressWarnings("deprecation")
public class BleClient {
    public interface Callback {
        void onScanResult(BluetoothDevice d, int rssi);
        void onScanStopped();
        void onConnected();
        void onMtu(int mtu);
        void onDiscovered(String ff01Info, String ff02Info);
        void onNotifyEnabled();
        void onWriteResult(boolean ok);
        void onNotification(byte[] value);
        void onDisconnected(int status);
        void onError(String msg);
    }

    public static final UUID SERVICE = UUID.fromString("0000FF00-0000-1000-8000-00805F9B34FB");
    public static final UUID FF01 = UUID.fromString("0000FF01-0000-1000-8000-00805F9B34FB");
    public static final UUID FF02 = UUID.fromString("0000FF02-0000-1000-8000-00805F9B34FB");
    public static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");

    private final Context ctx;
    private final Callback cb;
    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic ff01, ff02;
    private BluetoothLeScanner scanner;
    private boolean scanning;
    private int mtu = 23;

    public BleClient(Context c, Callback cb) { this.ctx = c.getApplicationContext(); this.cb = cb; }

    public int getMtu() { return mtu; }

    // ---------------- Quét ----------------
    private final ScanCallback scanCb = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult r) { cb.onScanResult(r.getDevice(), r.getRssi()); }
        @Override public void onScanFailed(int code) { scanning = false; cb.onError("Quét thất bại, mã " + code); cb.onScanStopped(); }
    };

    public boolean startScan(long durationMs) {
        BluetoothManager bm = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
        if (ad == null || !ad.isEnabled()) { cb.onError("Bluetooth đang tắt"); return false; }
        scanner = ad.getBluetoothLeScanner();
        if (scanner == null) { cb.onError("Không có BLE scanner"); return false; }
        scanning = true;
        scanner.startScan(null, new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb);
        main.postDelayed(new Runnable() { public void run() { stopScan(); } }, durationMs);
        return true;
    }

    public void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { scanner.stopScan(scanCb); } catch (RuntimeException ignored) {}
        cb.onScanStopped();
    }

    // ---------------- Kết nối ----------------
    public void connect(BluetoothDevice d) {
        close();
        gatt = d.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE);
        if (gatt == null) cb.onError("connectGatt thất bại");
    }

    public void close() {
        ff01 = null; ff02 = null;
        if (gatt != null) { try { gatt.disconnect(); gatt.close(); } catch (RuntimeException ignored) {} gatt = null; }
    }

    private static String props(BluetoothGattCharacteristic c) {
        int p = c.getProperties();
        StringBuilder sb = new StringBuilder();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) sb.append("READ ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) sb.append("WRITE ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) sb.append("WRITE_NO_RESP ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) sb.append("NOTIFY ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) sb.append("INDICATE ");
        return sb.toString().trim();
    }

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(final BluetoothGatt g, final int status, final int newState) {
            main.post(new Runnable() { public void run() {
                if (g != gatt) return;
                if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                    cb.onConnected();
                    if (!g.requestMtu(247)) g.discoverServices();
                } else {
                    close();
                    cb.onDisconnected(status);
                }
            }});
        }

        @Override public void onMtuChanged(final BluetoothGatt g, final int m, final int status) {
            main.post(new Runnable() { public void run() {
                if (g != gatt) return;
                if (status == BluetoothGatt.GATT_SUCCESS) mtu = m;
                cb.onMtu(mtu);
                if (!g.discoverServices()) cb.onError("discoverServices thất bại");
            }});
        }

        @Override public void onServicesDiscovered(final BluetoothGatt g, final int status) {
            main.post(new Runnable() { public void run() {
                if (g != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) { cb.onError("Khám phá service lỗi " + status); return; }
                BluetoothGattService s = g.getService(SERVICE);
                if (s == null) { cb.onError("Không tìm thấy service FF00"); return; }
                BluetoothGattCharacteristic c1 = s.getCharacteristic(FF01);
                BluetoothGattCharacteristic c2 = s.getCharacteristic(FF02);
                if (c1 == null) { cb.onError("Không tìm thấy FF01"); return; }
                if (c2 == null) { cb.onError("Không tìm thấy FF02"); return; }
                int p1 = c1.getProperties(), p2 = c2.getProperties();
                if ((p1 & (BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_INDICATE)) == 0) {
                    cb.onError("FF01 không hỗ trợ Notify/Indicate (" + props(c1) + ")"); return; }
                if ((p2 & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) {
                    cb.onError("FF02 không cho phép ghi (" + props(c2) + ")"); return; }
                ff01 = c1; ff02 = c2;
                cb.onDiscovered("FF01 [" + props(c1) + "]", "FF02 [" + props(c2) + "]");
                enableNotify(g);
            }});
        }

        private void enableNotify(BluetoothGatt g) {
            if (!g.setCharacteristicNotification(ff01, true)) { cb.onError("setCharacteristicNotification(FF01) thất bại"); return; }
            BluetoothGattDescriptor d = ff01.getDescriptor(CCCD);
            if (d == null) { cb.onError("FF01 không có CCCD 2902"); return; }
            boolean notify = (ff01.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0;
            d.setValue(notify ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
            if (!g.writeDescriptor(d)) cb.onError("Ghi CCCD thất bại");
        }

        @Override public void onDescriptorWrite(final BluetoothGatt g, final BluetoothGattDescriptor d, final int status) {
            main.post(new Runnable() { public void run() {
                if (g != gatt || !CCCD.equals(d.getUuid()) || !FF01.equals(d.getCharacteristic().getUuid())) return;
                if (status == BluetoothGatt.GATT_SUCCESS) cb.onNotifyEnabled();
                else cb.onError("Bật Notify FF01 lỗi, status " + status);
            }});
        }

        @Override public void onCharacteristicWrite(final BluetoothGatt g, final BluetoothGattCharacteristic c, final int status) {
            main.post(new Runnable() { public void run() {
                if (g != gatt || !FF02.equals(c.getUuid())) return;
                cb.onWriteResult(status == BluetoothGatt.GATT_SUCCESS);
            }});
        }

        // API < 33
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (!FF01.equals(c.getUuid())) return;
            deliver(g, c.getValue() == null ? new byte[0] : c.getValue().clone());
        }

        // API 33+
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            if (!FF01.equals(c.getUuid())) return;
            deliver(g, value.clone());
        }

        private void deliver(final BluetoothGatt g, final byte[] v) {
            main.post(new Runnable() { public void run() { if (g == gatt) cb.onNotification(v); }});
        }
    };

    /** Ghi một gói qua FF02. Dùng WRITE (có response) nếu có; nếu không dùng WRITE_NO_RESPONSE. */
    public boolean write(byte[] data) {
        if (gatt == null || ff02 == null) return false;
        boolean withResp = (ff02.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0;
        ff02.setWriteType(withResp ? BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT : BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        ff02.setValue(data);
        return gatt.writeCharacteristic(ff02);
    }
}
