package com.twc.loader.core;

import java.util.EnumSet;
import java.util.Set;

/** State machine có bảng chuyển trạng thái; chuyển sai bị từ chối. */
public final class StateMachine {
    public interface Listener { void onState(TransferState from, TransferState to); void onIllegal(TransferState from, TransferState to); }

    private TransferState state = TransferState.DISCONNECTED;
    private Listener listener;

    public void setListener(Listener l) { listener = l; }
    public TransferState get() { return state; }

    private static Set<TransferState> allowed(TransferState s) {
        switch (s) {
            case DISCONNECTED: return EnumSet.of(TransferState.SCANNING, TransferState.CONNECTING);
            case SCANNING: return EnumSet.of(TransferState.DISCONNECTED, TransferState.CONNECTING);
            case CONNECTING: return EnumSet.of(TransferState.DISCOVERING);
            case DISCOVERING: return EnumSet.of(TransferState.ENABLING_NOTIFY);
            case ENABLING_NOTIFY: return EnumSet.of(TransferState.READY);
            case READY: return EnumSet.of(TransferState.SENDING_D5);
            case SENDING_D5: return EnumSet.of(TransferState.WAIT_81, TransferState.CANCELLED);
            case WAIT_81: return EnumSet.of(TransferState.READY_TO_SEND_D6, TransferState.CANCELLED);
            case READY_TO_SEND_D6: return EnumSet.of(TransferState.SENDING_D6, TransferState.CANCELLED);
            case SENDING_D6: return EnumSet.of(TransferState.PAUSED, TransferState.WAIT_82, TransferState.CANCELLED);
            case PAUSED: return EnumSet.of(TransferState.SENDING_D6, TransferState.WAIT_82, TransferState.CANCELLED);
            case WAIT_82: return EnumSet.of(TransferState.COMPLETE, TransferState.CANCELLED);
            case COMPLETE: case ERROR: case CANCELLED:
                return EnumSet.of(TransferState.READY, TransferState.SCANNING, TransferState.CONNECTING);
            default: return EnumSet.noneOf(TransferState.class);
        }
    }

    /** ERROR và DISCONNECTED luôn được phép (mất kết nối / lỗi có thể xảy ra bất kỳ lúc nào). */
    public boolean transition(TransferState to) {
        if (to == state) return true;
        boolean ok = to == TransferState.ERROR || to == TransferState.DISCONNECTED || allowed(state).contains(to);
        if (!ok) { if (listener != null) listener.onIllegal(state, to); return false; }
        TransferState from = state;
        state = to;
        if (listener != null) listener.onState(from, to);
        return true;
    }
}
