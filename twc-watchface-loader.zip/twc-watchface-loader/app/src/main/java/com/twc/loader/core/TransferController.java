package com.twc.loader.core;

/**
 * Điều phối D5 -> chờ 81 -> D6 từng gói -> chờ 82. Thuần Java, chạy trên một luồng (main).
 * Mỗi lúc chỉ có tối đa 1 thao tác ghi đang chờ callback.
 */
public final class TransferController {
    public interface Transport { boolean write(byte[] data); }
    public interface Scheduler { void post(Runnable r, long delayMs); }
    public interface Listener {
        void onLog(boolean tx, byte[] data);
        void onMessage(String msg);
        void onProgress(int packetsSent, int packetsTotal, long bytesSent, long bytesTotal);
    }

    public static final long WAIT_81_TIMEOUT_MS = 10_000;

    private final StateMachine sm;
    private final Transport transport;
    private final Scheduler scheduler;
    private final Listener listener;

    private int session;
    private boolean strictLen = true;
    private int delayMs = 200;
    private byte[] d5;
    private D6Packetizer pk;
    private long binLen, sentBytes;
    private int nextIndex, sentPackets;
    private boolean writeInFlight, early81, early82;

    public TransferController(StateMachine sm, Transport t, Scheduler s, Listener l) {
        this.sm = sm; this.transport = t; this.scheduler = s; this.listener = l;
    }

    public boolean pendingWrite() { return writeInFlight; }
    public void setDelayMs(int ms) { delayMs = ms; }
    public void setStrictLength(boolean b) { strictLen = b; }

    /** Bắt đầu phiên mới. Chỉ khi READY. */
    public boolean start(byte[] d5Code, byte[] bin, int attSize) {
        if (sm.get() != TransferState.READY) { listener.onMessage("Chưa sẵn sàng (trạng thái " + sm.get() + ")"); return false; }
        if (d5Code == null || d5Code.length == 0) { listener.onMessage("Mã D5 rỗng"); return false; }
        if (bin == null || bin.length == 0) { listener.onMessage("File BIN rỗng/chưa chọn"); return false; }
        try { pk = new D6Packetizer(bin, attSize); } catch (RuntimeException e) { listener.onMessage(e.getMessage()); return false; }
        session++;
        d5 = d5Code.clone();
        binLen = bin.length; sentBytes = 0; nextIndex = 0; sentPackets = 0;
        writeInFlight = false; early81 = false; early82 = false;
        listener.onProgress(0, pk.count(), 0, binLen);
        sm.transition(TransferState.SENDING_D5);
        return doWrite(d5);
    }

    private boolean doWrite(byte[] data) {
        listener.onLog(true, data);
        writeInFlight = true;
        boolean ok;
        try { ok = transport.write(data); } catch (RuntimeException e) { ok = false; }
        if (!ok) { writeInFlight = false; fail("Lệnh ghi GATT bị từ chối"); return false; }
        return true;
    }

    /** Gọi khi onCharacteristicWrite trả về. */
    public void onWriteResult(boolean ok) {
        if (!writeInFlight) return;
        writeInFlight = false;
        TransferState st = sm.get();
        if (!ok) { fail("GATT ghi lỗi"); return; }
        if (st == TransferState.SENDING_D5) {
            sm.transition(TransferState.WAIT_81);
            final int s = session;
            scheduler.post(new Runnable() { public void run() {
                if (s == session && sm.get() == TransferState.WAIT_81) fail("Quá thời gian chờ phản hồi 81");
            }}, WAIT_81_TIMEOUT_MS);
            if (early81) { early81 = false; got81(); }
        } else if (st == TransferState.SENDING_D6 || st == TransferState.PAUSED) {
            sentBytes += pk.dataLength(nextIndex);
            sentPackets++; nextIndex++;
            listener.onProgress(sentPackets, pk.count(), sentBytes, binLen);
            if (nextIndex >= pk.count()) {
                sm.transition(TransferState.WAIT_82);
                listener.onMessage("ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN.");
                if (early82) { early82 = false; got82(); }
            } else if (st == TransferState.SENDING_D6) {
                scheduleNext();
            }
        }
    }

    private void scheduleNext() {
        final int s = session;
        scheduler.post(new Runnable() { public void run() { sendNext(s); } }, delayMs);
    }

    private void sendNext(int s) {
        if (s != session || sm.get() != TransferState.SENDING_D6 || writeInFlight) return;
        if (nextIndex >= pk.count()) return;
        doWrite(pk.packet(nextIndex));
    }

    /** Gọi khi nhận Notify từ FF01. */
    public void onNotify(byte[] data) {
        listener.onLog(false, data);
        TransferState st = sm.get();
        if (D5Frame.check(data, 0x81, strictLen) == null) {
            if (st == TransferState.WAIT_81) got81();
            else if (st == TransferState.SENDING_D5 && writeInFlight) early81 = true;
            else listener.onMessage("Bỏ qua 81 ngoài thời điểm chờ (" + st + ")");
        } else if (D5Frame.check(data, 0x82, strictLen) == null) {
            if (st == TransferState.WAIT_82) got82();
            else if ((st == TransferState.SENDING_D6 || st == TransferState.PAUSED) && writeInFlight && nextIndex == pk.count() - 1) early82 = true;
            else listener.onMessage("Bỏ qua 82 ngoài thời điểm chờ (" + st + ")");
        } else if (st == TransferState.WAIT_81) {
            listener.onMessage("Gói RX không phải 81 hợp lệ: " + D5Frame.check(data, 0x81, strictLen));
        }
    }

    private void got81() {
        sm.transition(TransferState.READY_TO_SEND_D6);
        sm.transition(TransferState.SENDING_D6);
        sendNext(session);
    }

    private void got82() {
        sm.transition(TransferState.COMPLETE);
        listener.onMessage("TRUYỀN DỮ LIỆU HOÀN TẤT");
    }

    public boolean pause() {
        if (sm.get() != TransferState.SENDING_D6) return false;
        return sm.transition(TransferState.PAUSED);
    }

    public boolean resume() {
        if (sm.get() != TransferState.PAUSED) return false;
        sm.transition(TransferState.SENDING_D6);
        if (!writeInFlight) scheduleNext();
        return true;
    }

    public void cancel() {
        TransferState st = sm.get();
        if (st == TransferState.SENDING_D5 || st == TransferState.WAIT_81 || st == TransferState.READY_TO_SEND_D6
                || st == TransferState.SENDING_D6 || st == TransferState.PAUSED || st == TransferState.WAIT_82) {
            session++;
            sm.transition(TransferState.CANCELLED);
            listener.onMessage("CANCELLED");
        }
    }

    /** Mất kết nối / Bluetooth tắt: dừng ngay, không tự tiếp tục. */
    public void onDisconnected() {
        session++; writeInFlight = false;
        sm.transition(TransferState.DISCONNECTED);
    }

    public void fail(String why) {
        session++;
        listener.onMessage("LỖI: " + why);
        sm.transition(TransferState.ERROR);
    }
}
