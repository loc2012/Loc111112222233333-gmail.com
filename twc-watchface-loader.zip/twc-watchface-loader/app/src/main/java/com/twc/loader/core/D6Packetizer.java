package com.twc.loader.core;

/**
 * Đóng gói D6.
 * CHƯA XÁC MINH: cấu trúc D6 chưa được xác nhận từ nhật ký. Giả thuyết duy nhất đang dùng:
 *   gói = [D6] + tối đa (attSize-1) byte BIN liên tiếp, giữ nguyên thứ tự, không header/checksum thêm.
 * Hãy chạy tools/verify_d6.py với nhật ký cũ để xác nhận trước khi tin kết quả.
 */
public final class D6Packetizer {
    public static final boolean STRUCTURE_VERIFIED = false;
    public static final int HEADER = 0xD6;
    private final byte[] bin;
    private final int chunk;
    private final int count;

    public D6Packetizer(byte[] bin, int attSize) {
        if (bin == null || bin.length == 0) throw new IllegalArgumentException("File rỗng");
        if (attSize < 2) throw new IllegalArgumentException("ATT quá nhỏ");
        this.bin = bin;
        this.chunk = attSize - 1;
        this.count = (bin.length + chunk - 1) / chunk;
    }

    public int count() { return count; }
    public int dataLength(int i) { return Math.min(chunk, bin.length - i * chunk); }

    public byte[] packet(int i) {
        if (i < 0 || i >= count) throw new IndexOutOfBoundsException();
        int n = dataLength(i);
        byte[] p = new byte[n + 1];
        p[0] = (byte) HEADER;
        System.arraycopy(bin, i * chunk, p, 1, n);
        return p;
    }
}
