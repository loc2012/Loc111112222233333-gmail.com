package com.twc.loader;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;

import com.twc.loader.core.*;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@SuppressLint("MissingPermission")
@SuppressWarnings("deprecation")
public class MainActivity extends Activity implements BleClient.Callback {
    static final String DEFAULT_D5 = "D5 05 01 01 00 00 00 06 00 FD 00 01 BB 30 CB";
    static final int REQ_PERM = 1, REQ_PICK = 2, REQ_EXPORT = 3;
    static final int ATT_D6 = 238;                 // ATT value đã quan sát
    static final int[] DELAYS = {20, 50, 100, 200};
    static final int MAX_BIN = 16 * 1024 * 1024;
    static final int UI_LOG_LINES = 150;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final StateMachine sm = new StateMachine();
    private BleClient ble;
    private TransferController ctl;

    private final List<BluetoothDevice> devices = new ArrayList<>();
    private final List<String> deviceLabels = new ArrayList<>();
    private ArrayAdapter<String> devAdapter;
    private int selected = -1;

    private byte[] bin; private String binName; 
    private final List<String> fullLog = new ArrayList<>();
    private final List<String> uiLog = new ArrayList<>();
    private boolean notifyOn, ffOk, connected;
    private long startMs; 

    private Button btnScan, btnConnect, btnSaveD5, btnResetD5, btnPick, btnStart, btnPause, btnResume, btnCancel, btnExport;
    private ListView list; private EditText etD5; private Spinner spDelay; private CheckBox cbLenient;
    private TextView tvConn, tvFF01, tvFF02, tvState, tvFile, tvSize, tvProgress, tvMsg, tvLog;
    private ProgressBar progress;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("twc", MODE_PRIVATE);
        bindViews();

        etD5.setText(prefs.getString("d5", DEFAULT_D5));
        spDelay.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"20 ms", "50 ms", "100 ms", "200 ms (mặc định, ổn định)"}));
        spDelay.setSelection(prefs.getInt("delayIdx", 3));
        devAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, deviceLabels);
        list.setAdapter(devAdapter);
        list.setOnItemClickListener((p, v, pos, id) -> selected = pos);

        ble = new BleClient(this, this);
        ctl = new TransferController(sm,
                data -> ble.write(data),
                (r, ms) -> main.postDelayed(r, ms),
                new TransferController.Listener() {
                    public void onLog(boolean tx, byte[] d) { addLog(tx, d); }
                    public void onMessage(String m) { tvMsg.setText(m); addLine("# " + m); }
                    public void onProgress(int ps, int pt, long bs, long bt) { showProgress(ps, pt, bs, bt); }
                });
        sm.setListener(new StateMachine.Listener() {
            public void onState(TransferState f, TransferState t) {
                addLine("# " + f + " -> " + t); refreshUi();
                if (t == TransferState.SENDING_D5) startMs = System.currentTimeMillis();
                setKeepOn(t == TransferState.SENDING_D5 || t == TransferState.WAIT_81 || t == TransferState.SENDING_D6
                        || t == TransferState.PAUSED || t == TransferState.WAIT_82);
            }
            public void onIllegal(TransferState f, TransferState t) { addLine("# CHUYỂN TRẠNG THÁI BỊ TỪ CHỐI " + f + " -> " + t); }
        });

        btnScan.setOnClickListener(v -> onScan());
        btnConnect.setOnClickListener(v -> onConnect());
        btnSaveD5.setOnClickListener(v -> saveD5());
        btnResetD5.setOnClickListener(v -> { etD5.setText(DEFAULT_D5); prefs.edit().putString("d5", DEFAULT_D5).apply(); toast("Đã khôi phục mặc định"); });
        btnPick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });
        btnStart.setOnClickListener(v -> onStart());
        btnPause.setOnClickListener(v -> ctl.pause());
        btnResume.setOnClickListener(v -> ctl.resume());
        btnCancel.setOnClickListener(v -> ctl.cancel());
        btnExport.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TITLE, "twc_log_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
            startActivityForResult(i, REQ_EXPORT);
        });
        refreshUi();
    }

    private void bindViews() {
        btnScan = findViewById(R.id.btnScan); btnConnect = findViewById(R.id.btnConnect);
        btnSaveD5 = findViewById(R.id.btnSaveD5); btnResetD5 = findViewById(R.id.btnResetD5);
        btnPick = findViewById(R.id.btnPick); btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause); btnResume = findViewById(R.id.btnResume);
        btnCancel = findViewById(R.id.btnCancel); btnExport = findViewById(R.id.btnExport);
        list = findViewById(R.id.listDevices); etD5 = findViewById(R.id.etD5);
        spDelay = findViewById(R.id.spDelay); cbLenient = findViewById(R.id.cbLenient);
        tvConn = findViewById(R.id.tvConn); tvFF01 = findViewById(R.id.tvFF01); tvFF02 = findViewById(R.id.tvFF02);
        tvState = findViewById(R.id.tvState); tvFile = findViewById(R.id.tvFile); tvSize = findViewById(R.id.tvSize);
        tvProgress = findViewById(R.id.tvProgress); tvMsg = findViewById(R.id.tvMsg); tvLog = findViewById(R.id.tvLog);
        progress = findViewById(R.id.progress);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private void setKeepOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // ---------- Quyền ----------
    private boolean hasPerms() {
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }
    private Runnable afterPerm;
    private void withPerms(Runnable r) {
        if (hasPerms()) { r.run(); return; }
        afterPerm = r;
        requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_PERM);
    }
    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] g) {
        if (rc == REQ_PERM) {
            if (hasPerms() && afterPerm != null) afterPerm.run(); else toast("Cần cấp quyền Bluetooth (Thiết bị lân cận)");
            afterPerm = null;
        }
    }

    // ---------- Quét / kết nối ----------
    private void onScan() {
        withPerms(() -> {
            TransferState st = sm.get();
            if (st != TransferState.DISCONNECTED && st != TransferState.ERROR && st != TransferState.CANCELLED && st != TransferState.COMPLETE) {
                toast("Đang bận, không thể quét lúc này"); return; }
            if (st != TransferState.DISCONNECTED) { ble.close(); ctl.onDisconnected(); }
            devices.clear(); deviceLabels.clear(); devAdapter.notifyDataSetChanged(); selected = -1; list.clearChoices();
            if (sm.transition(TransferState.SCANNING)) { if (!ble.startScan(10000)) sm.transition(TransferState.DISCONNECTED); }
        });
    }

    @Override public void onScanResult(BluetoothDevice d, int rssi) {
        String name = d.getName();
        if (name == null) return;                       // chỉ hiện thiết bị có tên
        for (int i = 0; i < devices.size(); i++) if (devices.get(i).getAddress().equals(d.getAddress())) return;
        devices.add(d); deviceLabels.add(name + "\n" + d.getAddress() + "  " + rssi + " dBm");
        devAdapter.notifyDataSetChanged();
    }
    @Override public void onScanStopped() { if (sm.get() == TransferState.SCANNING) sm.transition(TransferState.DISCONNECTED); }

    private void onConnect() {
        if (selected < 0 || selected >= devices.size()) { toast("Hãy chọn một thiết bị trong danh sách"); return; }
        withPerms(() -> {
            ble.stopScan();
            if (sm.get() != TransferState.DISCONNECTED && sm.get() != TransferState.ERROR
                    && sm.get() != TransferState.CANCELLED && sm.get() != TransferState.COMPLETE) { toast("Đang bận"); return; }
            notifyOn = false; ffOk = false; connected = false;
            tvFF01.setText("FF01: —"); tvFF02.setText("FF02: —");
            if (sm.transition(TransferState.CONNECTING)) ble.connect(devices.get(selected));
        });
    }

    @Override public void onConnected() { connected = true; tvConn.setText("Kết nối: đã kết nối GATT"); sm.transition(TransferState.DISCOVERING); }
    @Override public void onMtu(int mtu) { addLine("# MTU = " + mtu + " (ATT tối đa " + (mtu - 3) + " byte)"); }
    @Override public void onDiscovered(String a, String b) { ffOk = true; tvFF01.setText(a + " — tìm thấy"); tvFF02.setText(b + " — tìm thấy"); sm.transition(TransferState.ENABLING_NOTIFY); }
    @Override public void onNotifyEnabled() { notifyOn = true; tvFF01.setText(tvFF01.getText() + ", Notify BẬT"); sm.transition(TransferState.READY); }
    @Override public void onWriteResult(boolean ok) { ctl.onWriteResult(ok); }
    @Override public void onNotification(byte[] v) { ctl.onNotify(v); }
    @Override public void onDisconnected(int status) {
        connected = false; notifyOn = false; ffOk = false;
        tvConn.setText("Kết nối: đã ngắt (status " + status + ")");
        addLine("# Mất kết nối, status " + status + ". Phiên truyền bị dừng; phải bắt đầu phiên mới.");
        ctl.onDisconnected();
    }
    @Override public void onError(String msg) {
        addLine("# LỖI: " + msg); tvMsg.setText("LỖI: " + msg);
        connected = false; notifyOn = false; ffOk = false;
        ctl.fail(msg);                                  // dừng ngay, không truyền
        ble.close();
    }

    // ---------- Mã D5 ----------
    private void saveD5() {
        try {
            byte[] b = HexUtil.parse(etD5.getText().toString());
            String norm = HexUtil.toHex(b);             // chỉ chuẩn hoá khoảng trắng/hoa-thường, không đổi byte
            etD5.setText(norm);
            prefs.edit().putString("d5", norm).apply();
            toast(D5Frame.sum8(b, b.length - 1) == (b[b.length - 1] & 0xFF) ? "Đã lưu mã" : "Đã lưu (cảnh báo: byte cuối khác tổng các byte trước)");
        } catch (IllegalArgumentException e) { toast("HEX không hợp lệ: " + e.getMessage()); }
    }

    // ---------- File BIN ----------
    @Override protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (rc == REQ_PICK) loadBin(uri); else if (rc == REQ_EXPORT) exportLog(uri);
    }

    private void loadBin(Uri uri) {
        try {
            ContentResolver cr = getContentResolver();
            String name = "?";
            try (Cursor c = cr.query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i); }
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream in = cr.openInputStream(uri)) {
                if (in == null) throw new IllegalStateException("Không mở được file");
                byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > MAX_BIN) throw new IllegalStateException("File quá lớn (> 16 MB)"); }
            }
            if (bo.size() == 0) throw new IllegalStateException("File rỗng");
            bin = bo.toByteArray(); binName = name;
            tvFile.setText("Tên file: " + name); tvSize.setText("Dung lượng: " + bin.length + " byte");
            addLine("# Đã chọn " + name + " (" + bin.length + " byte)");
        } catch (Exception e) { bin = null; toast("Không đọc được file: " + e.getMessage()); tvFile.setText("Tên file: —"); tvSize.setText("Dung lượng: —"); }
        refreshUi();
    }

    // ---------- Bắt đầu ----------
    private void onStart() {
        TransferState st = sm.get();
        if ((st == TransferState.COMPLETE || st == TransferState.ERROR || st == TransferState.CANCELLED) && connected && notifyOn && ffOk) {
            sm.transition(TransferState.READY);         // phiên mới, rõ ràng: sẽ gửi lại D5 từ đầu
        }
        if (sm.get() != TransferState.READY || !connected || !notifyOn || !ffOk) { toast("Chưa sẵn sàng: cần kết nối, FF01 Notify, FF02"); return; }
        if (bin == null || bin.length == 0) { toast("Chưa chọn file BIN"); return; }
        String saved = prefs.getString("d5", DEFAULT_D5);
        byte[] d5;
        try {
            d5 = HexUtil.parse(saved);
            if (!HexUtil.toHex(HexUtil.parse(etD5.getText().toString())).equals(HexUtil.toHex(d5))) { toast("Mã D5 trong khung chưa được lưu — bấm LƯU MÃ"); return; }
        } catch (IllegalArgumentException e) { toast("Mã D5 không hợp lệ"); return; }
        int maxAtt = ble.getMtu() - 3;
        if (maxAtt < ATT_D6) { toast("MTU quá nhỏ (" + ble.getMtu() + "), cần ATT ≥ " + ATT_D6); return; }
        int idx = spDelay.getSelectedItemPosition();
        prefs.edit().putInt("delayIdx", idx).apply();
        ctl.setDelayMs(DELAYS[idx]);
        ctl.setStrictLength(!cbLenient.isChecked());
        tvMsg.setText("");
        ctl.start(d5, bin, ATT_D6);
    }

    // ---------- UI ----------
    private void showProgress(int ps, int pt, long bs, long bt) {
        progress.setProgress(bt == 0 ? 0 : (int) (bs * 1000 / bt));
        double sec = Math.max(0.001, (System.currentTimeMillis() - startMs) / 1000.0);
        tvProgress.setText(bs + " / " + bt + " byte (" + String.format(Locale.US, "%.1f", bs * 100.0 / Math.max(1, bt)) + "%)\n"
                + "Gói: " + ps + " / " + pt + " (còn " + (pt - ps) + ")  ~" + String.format(Locale.US, "%.0f", bs / sec) + " B/s");
    }

    private void refreshUi() {
        TransferState st = sm.get();
        tvState.setText("Trạng thái: " + st);
        boolean busy = st == TransferState.SENDING_D5 || st == TransferState.WAIT_81 || st == TransferState.READY_TO_SEND_D6
                || st == TransferState.SENDING_D6 || st == TransferState.PAUSED || st == TransferState.WAIT_82;
        boolean idle = !busy;
        btnScan.setEnabled(st == TransferState.DISCONNECTED || st == TransferState.ERROR || st == TransferState.CANCELLED || st == TransferState.COMPLETE);
        btnConnect.setEnabled(btnScan.isEnabled() || st == TransferState.SCANNING);
        btnSaveD5.setEnabled(idle); btnResetD5.setEnabled(idle); etD5.setEnabled(idle);
        btnPick.setEnabled(idle); spDelay.setEnabled(idle); cbLenient.setEnabled(idle);
        boolean canStart = connected && notifyOn && ffOk && bin != null
                && (st == TransferState.READY || st == TransferState.COMPLETE || st == TransferState.ERROR || st == TransferState.CANCELLED);
        btnStart.setEnabled(canStart);
        btnPause.setEnabled(st == TransferState.SENDING_D6);
        btnResume.setEnabled(st == TransferState.PAUSED);
        btnCancel.setEnabled(busy);
        if (st == TransferState.DISCONNECTED) tvConn.setText("Kết nối: chưa kết nối");
    }

    // ---------- Nhật ký ----------
    private static String stamp() { return new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()); }

    private void addLog(boolean tx, byte[] d) {
        String hex = HexUtil.toHex(d);
        String head = stamp() + " " + (tx ? "TX" : "RX") + " " + (tx ? "FF02" : "FF01") + " [" + d.length + " byte]";
        fullLog.add(head + ":\n" + hex);
        String shown = d.length > 32 ? HexUtil.toHex(d, 0, 32) + " … (+" + (d.length - 32) + " byte, xem đủ trong file TXT)" : hex;
        pushUi(head + "\n" + shown);
    }
    private void addLine(String s) { String l = stamp() + " " + s; fullLog.add(l); pushUi(l); }
    private void pushUi(String s) {
        uiLog.add(s);
        while (uiLog.size() > UI_LOG_LINES) uiLog.remove(0);
        tvLog.setText(String.join("\n", uiLog));
    }

    private void exportLog(Uri uri) {
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            os.write(String.join("\n", fullLog).getBytes(StandardCharsets.UTF_8));
            toast("Đã xuất nhật ký");
        } catch (Exception e) { toast("Xuất lỗi: " + e.getMessage()); }
    }

    @Override protected void onStop() {
        super.onStop();
        // Activity không còn hiển thị: nếu đang truyền thì dừng, không để gửi khi trạng thái không hợp lệ.
        TransferState st = sm.get();
        if (st == TransferState.SENDING_D6) ctl.pause();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ctl.onDisconnected();
        ble.close();
    }
}
