package com.twc.watchfaceloader

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * D5 -> chờ 81 -> [ nhóm 10 gói D6 -> D5 02 -> chờ 82 ] x N -> COMPLETED.
 * Mọi thứ chạy trên luồng chính; chỉ có tối đa 1 thao tác ghi đang chờ callback.
 * Không gửi nhóm kế tiếp nếu chưa nhận ACK 82 của nhóm trước.
 */
class TransferEngine(private val ble: BleClient, private val log: HexLog) {
    companion object {
        const val WAIT_81_MS = 15_000L
        const val WAIT_ACK_MS = 15_000L
    }

    data class Progress(
        val sent: Long, val total: Long, val pkts: Int, val totalPkts: Int, val bps: Long,
        val groupsDone: Int, val totalGroups: Int
    )

    private val h = Handler(Looper.getMainLooper())
    var state = State.DISCONNECTED; private set
    var onState: ((State, String) -> Unit)? = null
    var onProgress: ((Progress) -> Unit)? = null

    private var groups: List<List<ByteArray>> = emptyList()
    private var gIdx = 0          // nhóm hiện tại
    private var pIdx = 0          // gói hiện tại trong nhóm
    private var pktsDone = 0
    private var totalPkts = 0
    private var groupsDone = 0
    private var sentBytes = 0L
    private var totalBytes = 0L
    private var intervalMs = 200L
    private var writeInFlight = false
    private var pauseReq = false
    private var early81 = false
    private var early82 = false
    private var t0 = 0L
    private var d5WriteStatus = -1
    private var rxBuf = ByteArray(0)

    val busy: Boolean
        get() = state in setOf(
            State.SENDING_D5, State.WAITING_FOR_81, State.READY_TO_SEND_D6, State.SENDING_D6,
            State.SENDING_D5_02, State.PAUSED, State.WAITING_FOR_82
        )

    fun setState(s: State, msg: String = "") {
        state = s
        log.info("STATE -> $s ${if (msg.isNotEmpty()) "($msg)" else ""}")
        onState?.invoke(s, msg)
    }

    // ---------------- timers ----------------
    private val timeout81 = Runnable {
        if (state == State.WAITING_FOR_81 || state == State.SENDING_D5) {
            log.info("KẾT THÚC thời gian chờ 81: hết $WAIT_81_MS ms, không có 81 hợp lệ")
            val why = when (d5WriteStatus) {
                -1 -> "callback ghi D5 không bao giờ đến"
                0 -> "callback ghi D5 thành công nhưng đồng hồ không phản hồi 81 hợp lệ"
                else -> "callback ghi D5 báo lỗi GATT status=$d5WriteStatus và đồng hồ không phản hồi 81 hợp lệ"
            }
            fail("Không nhận được 81 sau ${WAIT_81_MS / 1000}s: $why. Không gửi D6.")
        }
    }
    private val ackTimeout = Runnable {
        if (state == State.WAITING_FOR_82 || state == State.SENDING_D5_02) {
            log.info("TIMEOUT: không nhận ACK 82 của nhóm ${gIdx + 1}/${groups.size} sau $WAIT_ACK_MS ms")
            fail("Hết thời gian chờ ACK 82 của nhóm ${gIdx + 1}/${groups.size}. Không gửi nhóm tiếp theo.")
        }
    }
    private val writeTimeout = Runnable {
        if (state == State.SENDING_D6 && writeInFlight) fail("Quá 5s không có callback ghi gói D6 #${pktsDone + 1}")
    }
    private val sendNextRunnable = Runnable { sendNextD6() }

    // ---------------- bắt đầu ----------------
    /** Trả về thông báo lỗi nếu không thể bắt đầu, null nếu đã bắt đầu. */
    fun start(d5: ByteArray, bin: ByteArray, interval: Long): String? {
        if (!ble.ready) return "Chưa kết nối hoặc chưa bật Notify FF01"
        if (state !in setOf(State.READY, State.COMPLETED, State.CANCELLED, State.ERROR))
            return "Đang bận, không thể bắt đầu"
        if (bin.isEmpty()) return "File BIN rỗng"
        if (d5.isEmpty()) return "Mã D5 rỗng"
        if (ble.attPayload < Protocol.D6_ATT_LEN)
            return "MTU hiện tại chỉ cho ${ble.attPayload} byte, cần ≥ ${Protocol.D6_ATT_LEN}. Kết nối lại."
        if (!D5Ctl.payloadRuleVerified) {
            val m = "CHƯA THỂ TRUYỀN: quy luật byte payload của gói D5 02 (B3/25/1C...) chưa được xác minh từ HCI gốc. " +
                "App từ chối tạo gói D5 02 giả định nên không gửi gì cả."
            log.info(m)
            return m
        }
        intervalMs = interval
        val pk = D6Packer.split(bin)
        groups = pk.chunked(Protocol.GROUP_SIZE)
        totalPkts = pk.size
        totalBytes = bin.size.toLong()
        gIdx = 0; pIdx = 0; pktsDone = 0; groupsDone = 0; sentBytes = 0
        writeInFlight = false; pauseReq = false
        early81 = false; early82 = false; rxBuf = ByteArray(0); d5WriteStatus = -1
        log.info("Phiên mới: BIN=${bin.size} byte, ${pk.size} gói D6 (ATT ${Protocol.D6_ATT_LEN} byte), " +
            "${groups.size} nhóm (tối đa ${Protocol.GROUP_SIZE} gói/nhóm), nghỉ ${interval}ms, mã D5 ${d5.size} byte")
        emitProgress()
        setState(State.SENDING_D5, "Gửi D5, kiểu ghi ${ble.writeTypeName}")
        log.info("BẮT ĐẦU thời gian chờ 81 ($WAIT_81_MS ms) – tính từ lúc gửi yêu cầu ghi D5")
        h.postDelayed(timeout81, WAIT_81_MS)
        if (!doWrite(d5)) {
            fail("Hệ thống từ chối yêu cầu ghi D5 (writeCharacteristic trả về false) – D5 CHƯA được gửi")
            return null
        }
        log.info("Đã GỬI YÊU CẦU ghi D5 (chưa phải bằng chứng đồng hồ đã nhận)")
        return null
    }

    private fun doWrite(data: ByteArray): Boolean {
        writeInFlight = true
        val ok = ble.write(data)
        if (ok) log.tx("FF02", data) else writeInFlight = false
        return ok
    }

    // ---------------- callback ghi ----------------
    fun onWriteDone(status: Int) {
        val ok = status == 0
        writeInFlight = false
        h.removeCallbacks(writeTimeout)
        when (state) {
            State.SENDING_D5 -> {
                d5WriteStatus = status
                if (ok) log.info("Callback ghi D5: THÀNH CÔNG (status=0) – stack BLE xác nhận ghi, chưa phải đồng hồ đã xử lý")
                else log.info("Callback ghi D5: LỖI GATT status=$status (0x${status.toString(16)}) – KHÔNG gửi lại D5, KHÔNG đóng phiên, tiếp tục nghe FF01 tới hết thời gian chờ")
                if (early81) accept81()
                else setState(State.WAITING_FOR_81, if (ok) "Chờ phản hồi 81" else "Callback ghi lỗi status=$status, vẫn chờ 81")
            }
            State.SENDING_D6 -> {
                if (!ok) { fail("GATT báo lỗi khi gửi gói D6 #${pktsDone + 1}, status=$status"); return }
                sentBytes += groups[gIdx][pIdx].size - 1
                pIdx++; pktsDone++
                emitProgress()
                when {
                    pIdx >= groups[gIdx].size -> sendCtl02()
                    pauseReq -> { pauseReq = false; setState(State.PAUSED, "Tạm dừng: nhóm ${gIdx + 1}, đã gửi $pIdx/${groups[gIdx].size} gói") }
                    else -> h.postDelayed(sendNextRunnable, intervalMs)
                }
            }
            State.SENDING_D5_02 -> {
                if (ok) log.info("Callback ghi D5 02 nhóm ${gIdx + 1}: THÀNH CÔNG (status=0)")
                else log.info("Callback ghi D5 02 nhóm ${gIdx + 1}: LỖI status=$status – KHÔNG gửi lại, chờ ACK 82 tới hết thời gian")
                if (early82) acceptAck()
                else setState(State.WAITING_FOR_82, ackWaitMsg())
            }
            else -> log.info("Callback ghi (status=$status) đến khi state=$state – bỏ qua")
        }
    }

    private fun ackWaitMsg() =
        if (gIdx == groups.size - 1) "ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN (ACK 82 nhóm cuối)"
        else "Chờ ACK 82 của nhóm ${gIdx + 1}/${groups.size}"

    // ---------------- 81 -> D6 ----------------
    private fun accept81() {
        h.removeCallbacks(timeout81)
        log.info("KẾT THÚC thời gian chờ 81: đã nhận 81 hợp lệ")
        rxBuf = ByteArray(0)
        setState(State.READY_TO_SEND_D6, "Đã nhận 81 hợp lệ (tiền tố D5 05 01 81 + khung + SUM8 đúng)")
        log.info(">>> CHUYỂN SANG SENDING_D6 vì: nhận 81 hợp lệ. Gửi D6 theo nhóm, một phiên duy nhất")
        t0 = SystemClock.elapsedRealtime()
        startGroup()
    }

    private fun startGroup() {
        pIdx = 0
        log.info("=== NHÓM ${gIdx + 1}/${groups.size}: ${groups[gIdx].size} gói D6 (gói tổng #${pktsDone + 1}..#${pktsDone + groups[gIdx].size}) ===")
        setState(State.SENDING_D6, "Nhóm ${gIdx + 1}/${groups.size}")
        sendNextD6()
    }

    private fun sendNextD6() {
        if (state != State.SENDING_D6 || writeInFlight) return
        if (!doWrite(groups[gIdx][pIdx])) fail("Không thể ghi gói D6 #${pktsDone + 1}")
        else h.postDelayed(writeTimeout, 5_000)
    }

    // ---------------- D5 02 + ACK 82 ----------------
    private fun sendCtl02() {
        val g = groups[gIdx]
        val pb = D5Ctl.payloadFor(g, gIdx, groups.size)
        if (pb == null) { fail("Quy luật byte D5 02 chưa xác minh – không tạo gói giả định"); return }
        val ctl = D5Ctl.build02(pb)
        early82 = false
        setState(State.SENDING_D5_02, "Gửi D5 02 sau nhóm ${gIdx + 1}/${groups.size} (${g.size} gói D6)")
        log.info("Gửi D5 02 nhóm ${gIdx + 1}: ${HexUtil.toHex(ctl)}")
        h.postDelayed(ackTimeout, WAIT_ACK_MS)
        if (!doWrite(ctl)) fail("Hệ thống từ chối yêu cầu ghi D5 02 – D5 02 CHƯA được gửi")
    }

    private fun acceptAck() {
        h.removeCallbacks(ackTimeout)
        early82 = false
        groupsDone++
        log.info("ACK 82 hợp lệ cho nhóm ${gIdx + 1}/${groups.size}. Số nhóm đã hoàn thành: $groupsDone/${groups.size}")
        gIdx++
        emitProgress()
        when {
            gIdx >= groups.size -> setState(State.COMPLETED, "TRUYỀN DỮ LIỆU HOÀN TẤT")
            pauseReq -> { pauseReq = false; pIdx = 0; setState(State.PAUSED, "Tạm dừng giữa nhóm: xong $groupsDone nhóm") }
            else -> startGroup()
        }
    }

    // ---------------- RX ----------------
    private fun label81(r: Protocol.Rx81) = when (r) {
        Protocol.Rx81.VALID -> "81 HỢP LỆ"
        Protocol.Rx81.INCOMPLETE -> "81 CHƯA ĐỦ DỮ LIỆU"
        Protocol.Rx81.INVALID -> "81 KHÔNG HỢP LỆ (sai khung/độ dài/SUM8)"
        Protocol.Rx81.NOT81 -> "KHÔNG NHẬN DIỆN (không phải 81)"
    }

    private fun is82(d: ByteArray) = Protocol.match(d, 0x82, Protocol.EXPECTED_82) == Protocol.Match.OK

    fun onRx(data: ByteArray) {
        log.rx("FF01", data)
        when (state) {
            State.SENDING_D5, State.WAITING_FOR_81 -> {
                var cand = if (rxBuf.isEmpty()) data else rxBuf + data
                var r = Protocol.classify81(cand)
                if (rxBuf.isNotEmpty() && (r == Protocol.Rx81.NOT81 || r == Protocol.Rx81.INVALID)) {
                    log.info("Ghép với phần dở trước đó không thành khung 81 -> xét gói mới riêng")
                    rxBuf = ByteArray(0); cand = data; r = Protocol.classify81(cand)
                }
                log.info("RX len=${data.size}: ${label81(r)}" + if (cand !== data) " (đã ghép, tổng ${cand.size} byte)" else "")
                when (r) {
                    Protocol.Rx81.VALID -> {
                        rxBuf = ByteArray(0)
                        if (state == State.SENDING_D5) early81 = true else accept81()
                    }
                    Protocol.Rx81.INCOMPLETE -> rxBuf = if (cand.size <= 300) cand else ByteArray(0)
                    else -> rxBuf = ByteArray(0)
                }
            }
            State.SENDING_D6, State.PAUSED, State.READY_TO_SEND_D6 -> {
                val r = Protocol.classify81(data)
                when {
                    r != Protocol.Rx81.NOT81 -> log.info("RX len=${data.size}: ${label81(r)} – đến khi đang truyền D6, BỎ QUA (không khởi động lại)")
                    is82(data) -> log.info("RX len=${data.size}: 82 NGOÀI LƯỢT (chưa gửi D5 02 của nhóm ${gIdx + 1}) – KHÔNG coi là ACK, BỎ QUA")
                    else -> log.info("RX len=${data.size}: KHÔNG NHẬN DIỆN, chỉ ghi nhật ký")
                }
            }
            State.SENDING_D5_02 -> {
                if (is82(data)) {
                    log.info("RX len=${data.size}: 82 đến trước callback ghi D5 02 – tính là ACK của nhóm ${gIdx + 1} (D5 02 đã được yêu cầu gửi)")
                    early82 = true
                } else log.info("RX len=${data.size}: KHÔNG NHẬN DIỆN, chỉ ghi nhật ký")
            }
            State.WAITING_FOR_82 -> {
                when {
                    is82(data) -> { log.info("RX len=${data.size}: 82 HỢP LỆ – ACK nhóm ${gIdx + 1}/${groups.size}"); acceptAck() }
                    Protocol.classify81(data) != Protocol.Rx81.NOT81 -> log.info("RX len=${data.size}: gói 81 đến muộn – bỏ qua")
                    else -> log.info("RX len=${data.size}: KHÔNG NHẬN DIỆN, không phải 82 (khác mẫu hoặc sai khung) – không coi là ACK")
                }
            }
            else -> log.info("RX len=${data.size}: ngoài phiên truyền, chỉ ghi nhật ký")
        }
    }

    // ---------------- điều khiển ----------------
    fun pause() {
        if (state != State.SENDING_D6) return
        if (writeInFlight) { pauseReq = true; log.info("Yêu cầu tạm dừng – chờ gói đang gửi xong") }
        else { h.removeCallbacks(sendNextRunnable); setState(State.PAUSED, "Tạm dừng: nhóm ${gIdx + 1}, đã gửi $pIdx/${groups[gIdx].size} gói") }
    }

    fun resume() {
        if (pauseReq) { pauseReq = false; log.info("Hủy yêu cầu tạm dừng"); return }
        if (state != State.PAUSED) return
        if (pIdx == 0) log.info("Tiếp tục: bắt đầu nhóm ${gIdx + 1}") else log.info("Tiếp tục từ gói ${pIdx + 1} của nhóm ${gIdx + 1}")
        setState(State.SENDING_D6, "Nhóm ${gIdx + 1}/${groups.size}")
        sendNextD6()
    }

    fun cancel() {
        if (!busy) return
        stopTimers()
        setState(State.CANCELLED, "CANCELLED – đã hủy, không gửi thêm")
    }

    fun fail(msg: String) {
        stopTimers()
        setState(State.ERROR, msg)
    }

    /** Gọi khi BLE báo mất kết nối. Không tự tiếp tục phiên cũ. */
    fun onDisconnected() {
        stopTimers()
        when {
            busy -> setState(State.ERROR, "Mất kết nối giữa chừng – phải kết nối lại và bắt đầu phiên mới")
            state == State.ERROR -> {}
            else -> setState(State.DISCONNECTED, "Đã ngắt kết nối")
        }
    }

    fun shutdown() { stopTimers(); if (busy) state = State.CANCELLED }

    private fun stopTimers() {
        h.removeCallbacks(timeout81); h.removeCallbacks(sendNextRunnable)
        h.removeCallbacks(writeTimeout); h.removeCallbacks(ackTimeout)
        pauseReq = false
    }

    private fun emitProgress() {
        val el = (SystemClock.elapsedRealtime() - t0).coerceAtLeast(1)
        val bps = if (t0 == 0L) 0 else sentBytes * 1000 / el
        onProgress?.invoke(Progress(sentBytes, totalBytes, pktsDone, totalPkts, bps, groupsDone, groups.size))
    }
}
