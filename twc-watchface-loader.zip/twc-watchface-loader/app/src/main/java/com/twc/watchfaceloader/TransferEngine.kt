package com.twc.watchfaceloader

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * State machine: D5 -> chờ 81 -> D6... -> chờ 82 -> COMPLETED.
 * Mọi thứ chạy trên luồng chính, mỗi lần chỉ có tối đa 1 thao tác ghi đang chờ callback.
 */
class TransferEngine(private val ble: BleClient, private val log: HexLog) {
    companion object { const val WAIT_81_MS = 15_000L }

    data class Progress(val sent: Long, val total: Long, val pkts: Int, val totalPkts: Int, val bps: Long)

    private val h = Handler(Looper.getMainLooper())
    var state = State.DISCONNECTED; private set
    var onState: ((State, String) -> Unit)? = null
    var onProgress: ((Progress) -> Unit)? = null

    private var packets: List<ByteArray> = emptyList()
    private var idx = 0
    private var sentBytes = 0L
    private var totalBytes = 0L
    private var intervalMs = 200L
    private var writeInFlight = false
    private var pauseReq = false
    private var early81 = false
    private var early82 = false
    private var t0 = 0L

    val busy: Boolean
        get() = state in setOf(
            State.SENDING_D5, State.WAITING_FOR_81, State.READY_TO_SEND_D6,
            State.SENDING_D6, State.PAUSED, State.WAITING_FOR_82
        )

    fun setState(s: State, msg: String = "") {
        state = s
        log.info("STATE -> $s ${if (msg.isNotEmpty()) "($msg)" else ""}")
        onState?.invoke(s, msg)
    }

    private var d5WriteStatus = -1   // -1 = chưa có callback ghi D5

    private val timeout81 = Runnable {
        if (state == State.WAITING_FOR_81 || state == State.SENDING_D5) {
            log.info("KẾT THÚC thời gian chờ 81: hết ${WAIT_81_MS} ms, không có 81 hợp lệ")
            val why = when (d5WriteStatus) {
                -1 -> "callback ghi D5 không bao giờ đến"
                0 -> "callback ghi D5 thành công nhưng đồng hồ không phản hồi 81 hợp lệ"
                else -> "callback ghi D5 báo lỗi GATT status=$d5WriteStatus và đồng hồ không phản hồi 81 hợp lệ"
            }
            fail("Không nhận được 81 sau ${WAIT_81_MS / 1000}s: $why. Không gửi D6.")
        }
    }
    private val writeTimeout = Runnable {
        if (state == State.SENDING_D6 && writeInFlight) fail("Quá 5s không có callback ghi gói D6 #${idx + 1}")
    }
    private val sendNextRunnable = Runnable { sendNextD6() }

    /** Trả về thông báo lỗi nếu không thể bắt đầu, null nếu đã bắt đầu. */
    fun start(d5: ByteArray, bin: ByteArray, interval: Long): String? {
        if (!ble.ready) return "Chưa kết nối hoặc chưa bật Notify FF01"
        if (state !in setOf(State.READY, State.COMPLETED, State.CANCELLED, State.ERROR))
            return "Đang bận, không thể bắt đầu"
        if (bin.isEmpty()) return "File BIN rỗng"
        if (d5.isEmpty()) return "Mã D5 rỗng"
        if (ble.attPayload < Protocol.D6_ATT_LEN)
            return "MTU hiện tại chỉ cho ${ble.attPayload} byte, cần ≥ ${Protocol.D6_ATT_LEN}. Kết nối lại."
        intervalMs = interval
        packets = D6Packer.split(bin)
        totalBytes = bin.size.toLong()
        idx = 0; sentBytes = 0; writeInFlight = false; pauseReq = false
        early81 = false; early82 = false; rxBuf = ByteArray(0); d5WriteStatus = -1
        log.info("Phiên mới: BIN=${bin.size} byte, ${packets.size} gói D6, nghỉ ${interval}ms, mã D5 ${d5.size} byte")
        emitProgress()
        setState(State.SENDING_D5, "Gửi D5, kiểu ghi ${ble.writeTypeName}")
        log.info("BẮT ĐẦU thời gian chờ 81 (${WAIT_81_MS} ms) – tính từ lúc gửi yêu cầu ghi D5")
        h.postDelayed(timeout81, WAIT_81_MS)
        if (!doWrite(d5)) { fail("Hệ thống từ chối yêu cầu ghi D5 (writeCharacteristic trả về false) – D5 CHƯA được gửi"); return null }
        log.info("Đã GỬI YÊU CẦU ghi D5 (chưa phải bằng chứng đồng hồ đã nhận)")
        return null
    }

    private fun doWrite(data: ByteArray): Boolean {
        writeInFlight = true
        val ok = ble.write(data)
        if (ok) log.tx("FF02", data) else writeInFlight = false
        return ok
    }

    fun onWriteDone(status: Int) {
        val ok = status == 0
        writeInFlight = false
        h.removeCallbacks(writeTimeout)
        when (state) {
            State.SENDING_D5 -> {
                d5WriteStatus = status
                if (ok) log.info("Callback ghi D5: THÀNH CÔNG (status=0) – đây mới chỉ là stack BLE xác nhận ghi, chưa phải đồng hồ đã xử lý")
                else log.info("Callback ghi D5: LỖI GATT status=$status (0x${status.toString(16)}) – KHÔNG gửi lại D5, KHÔNG đóng phiên, tiếp tục lắng nghe FF01 tới hết thời gian chờ")
                if (early81) accept81()
                else setState(State.WAITING_FOR_81, if (ok) "Chờ phản hồi 81" else "Callback ghi lỗi status=$status, vẫn chờ 81")
            }
            State.SENDING_D6 -> {
                if (!ok) { fail("GATT báo lỗi khi gửi gói D6 #${idx + 1}, status=$status"); return }
                sentBytes += packets[idx].size - 1
                idx++
                emitProgress()
                when {
                    idx >= packets.size -> finishD6()
                    pauseReq -> { pauseReq = false; setState(State.PAUSED, "Tạm dừng tại gói $idx/${packets.size}") }
                    else -> h.postDelayed(sendNextRunnable, intervalMs)
                }
            }
            else -> log.info("Callback ghi (status=$status) đến khi state=$state – bỏ qua")
        }
    }

    private fun accept81() {
        h.removeCallbacks(timeout81)
        log.info("KẾT THÚC thời gian chờ 81: đã nhận 81 hợp lệ")
        rxBuf = ByteArray(0)
        setState(State.READY_TO_SEND_D6, "Đã nhận 81 hợp lệ (tiền tố D5 05 01 81 + khung đúng độ dài)")
        log.info(">>> CHUYỂN SANG SENDING_D6 vì: nhận 81 hợp lệ. Gửi D6 một lần duy nhất cho phiên này")
        t0 = SystemClock.elapsedRealtime()
        setState(State.SENDING_D6, "Đang gửi D6")
        sendNextD6()
    }

    private fun sendNextD6() {
        if (state != State.SENDING_D6 || writeInFlight) return
        if (idx >= packets.size) { finishD6(); return }
        if (!doWrite(packets[idx])) fail("Không thể ghi gói D6 #${idx + 1}")
        else h.postDelayed(writeTimeout, 5_000)
    }

    private fun finishD6() {
        setState(State.WAITING_FOR_82, "ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN")
        if (early82) accept82()
    }

    private fun accept82() {
        setState(State.COMPLETED, "TRUYỀN DỮ LIỆU HOÀN TẤT")
    }

    private var rxBuf = ByteArray(0)

    private fun label81(r: Protocol.Rx81) = when (r) {
        Protocol.Rx81.VALID -> "81 HỢP LỆ"
        Protocol.Rx81.INCOMPLETE -> "81 CHƯA ĐỦ DỮ LIỆU"
        Protocol.Rx81.INVALID -> "81 KHÔNG HỢP LỆ (sai khung/độ dài)"
        Protocol.Rx81.NOT81 -> "KHÔNG NHẬN DIỆN (không phải 81)"
    }

    fun onRx(data: ByteArray) {
        log.rx("FF01", data)
        when (state) {
            State.SENDING_D5, State.WAITING_FOR_81 -> {
                // Ghép phần dở dang trước đó (nếu có) với gói mới
                var cand = if (rxBuf.isEmpty()) data else rxBuf + data
                var r = Protocol.classify81(cand)
                if (rxBuf.isNotEmpty() && (r == Protocol.Rx81.NOT81 || r == Protocol.Rx81.INVALID)) {
                    log.info("Ghép với phần dở trước đó không thành khung 81 -> xét gói mới riêng")
                    rxBuf = ByteArray(0); cand = data; r = Protocol.classify81(cand)
                }
                log.info("RX len=${data.size}: ${label81(r)}" + if (cand !== data) " (đã ghép, tổng ${cand.size} byte)" else "")
                when (r) {
                    Protocol.Rx81.VALID -> {
                        rxBuf = ByteArray(0)
                        if (state == State.SENDING_D5) early81 = true else accept81()
                    }
                    Protocol.Rx81.INCOMPLETE -> rxBuf = if (cand.size <= 300) cand else ByteArray(0)
                    else -> rxBuf = ByteArray(0)
                }
            }
            State.SENDING_D6, State.PAUSED -> {
                val r = Protocol.classify81(data)
                if (r != Protocol.Rx81.NOT81) log.info("RX len=${data.size}: ${label81(r)} – đến khi đang truyền D6, BỎ QUA (không khởi động lại)")
                else if (state == State.SENDING_D6 &&
                    Protocol.match(data, 0x82, Protocol.EXPECTED_82) == Protocol.Match.OK &&
                    writeInFlight && idx == packets.size - 1) early82 = true
                else log.info("RX len=${data.size}: KHÔNG NHẬN DIỆN, chỉ ghi nhật ký")
            }
            State.WAITING_FOR_82 -> when (Protocol.match(data, 0x82, Protocol.EXPECTED_82)) {
                Protocol.Match.OK -> accept82()
                Protocol.Match.STRUCT_ONLY ->
                    log.info("RX len=${data.size}: giống 82 nhưng KHÁC mẫu -> không báo hoàn tất")
                Protocol.Match.NO -> {
                    val r = Protocol.classify81(data)
                    log.info("RX len=${data.size}: " + if (r != Protocol.Rx81.NOT81) "${label81(r)} – đến muộn, bỏ qua" else "KHÔNG NHẬN DIỆN")
                }
            }
            else -> log.info("RX len=${data.size}: ngoài phiên truyền, chỉ ghi nhật ký")
        }
    }

    fun pause() {
        if (state != State.SENDING_D6) return
        if (writeInFlight) { pauseReq = true; log.info("Yêu cầu tạm dừng – chờ gói đang gửi xong") }
        else { h.removeCallbacks(sendNextRunnable); setState(State.PAUSED, "Tạm dừng tại gói $idx/${packets.size}") }
    }

    fun resume() {
        if (pauseReq) { pauseReq = false; log.info("Hủy yêu cầu tạm dừng"); return }
        if (state != State.PAUSED) return
        setState(State.SENDING_D6, "Tiếp tục từ gói ${idx + 1}")
        sendNextD6()
    }

    fun cancel() {
        if (!busy) return
        stopTimers()
        setState(State.CANCELLED, "CANCELLED – đã hủy, không gửi thêm")
    }

    fun fail(msg: String) {
        stopTimers()
        setState(State.ERROR, msg)
    }

    /** Gọi khi BLE báo mất kết nối. Không tự tiếp tục phiên cũ. */
    fun onDisconnected() {
        stopTimers()
        when {
            busy -> setState(State.ERROR, "Mất kết nối giữa chừng – phải kết nối lại và bắt đầu phiên mới")
            state == State.ERROR -> {}
            else -> setState(State.DISCONNECTED, "Đã ngắt kết nối")
        }
    }

    fun shutdown() { stopTimers(); if (busy) state = State.CANCELLED }

    private fun stopTimers() {
        h.removeCallbacks(timeout81); h.removeCallbacks(sendNextRunnable); h.removeCallbacks(writeTimeout)
        pauseReq = false
    }

    private fun emitProgress() {
        val el = (SystemClock.elapsedRealtime() - t0).coerceAtLeast(1)
        val bps = if (t0 == 0L) 0 else sentBytes * 1000 / el
        onProgress?.invoke(Progress(sentBytes, totalBytes, idx, packets.size, bps))
    }
}
