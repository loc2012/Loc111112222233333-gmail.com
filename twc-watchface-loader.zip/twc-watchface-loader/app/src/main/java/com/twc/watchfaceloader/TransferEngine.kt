package com.twc.watchfaceloader

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * State machine: D5 -> chờ 81 -> D6... -> chờ 82 -> COMPLETE.
 * Mọi thứ chạy trên luồng chính, mỗi lần chỉ có tối đa 1 thao tác ghi đang chờ callback.
 */
class TransferEngine(private val ble: BleClient, private val log: HexLog) {

    data class Progress(val sent: Long, val total: Long, val pkts: Int, val totalPkts: Int, val bps: Long)

    private val h = Handler(Looper.getMainLooper())
    var state = State.DISCONNECTED; private set
    var onState: ((State, String) -> Unit)? = null
    var onProgress: ((Progress) -> Unit)? = null

    private var packets: List<ByteArray> = emptyList()
    private var idx = 0
    private var sentBytes = 0L
    private var totalBytes = 0L
    private var intervalMs = 200L
    private var writeInFlight = false
    private var pauseReq = false
    private var early81 = false
    private var early82 = false
    private var t0 = 0L

    val busy: Boolean
        get() = state in setOf(
            State.SENDING_D5, State.WAIT_81, State.READY_TO_SEND_D6,
            State.SENDING_D6, State.PAUSED, State.WAIT_82
        )

    fun setState(s: State, msg: String = "") {
        state = s
        log.info("STATE -> $s ${if (msg.isNotEmpty()) "($msg)" else ""}")
        onState?.invoke(s, msg)
    }

    private val timeout81 = Runnable {
        if (state == State.WAIT_81) fail("Hết thời gian chờ phản hồi 81 – không gửi D6")
    }
    private val sendNextRunnable = Runnable { sendNextD6() }

    /** Trả về thông báo lỗi nếu không thể bắt đầu, null nếu đã bắt đầu. */
    fun start(d5: ByteArray, bin: ByteArray, interval: Long): String? {
        if (!ble.ready) return "Chưa kết nối hoặc chưa bật Notify FF01"
        if (state !in setOf(State.READY, State.COMPLETE, State.CANCELLED, State.ERROR))
            return "Đang bận, không thể bắt đầu"
        if (bin.isEmpty()) return "File BIN rỗng"
        if (d5.isEmpty()) return "Mã D5 rỗng"
        if (ble.attPayload < Protocol.D6_ATT_LEN)
            return "MTU hiện tại chỉ cho ${ble.attPayload} byte, cần ≥ ${Protocol.D6_ATT_LEN}. Kết nối lại."
        intervalMs = interval
        packets = D6Packer.split(bin)
        totalBytes = bin.size.toLong()
        idx = 0; sentBytes = 0; writeInFlight = false; pauseReq = false
        early81 = false; early82 = false
        log.info("Phiên mới: BIN=${bin.size} byte, ${packets.size} gói D6, nghỉ ${interval}ms, mã D5 ${d5.size} byte")
        emitProgress()
        setState(State.SENDING_D5, "Gửi D5")
        if (!doWrite(d5)) { fail("Ghi D5 thất bại"); return null }
        return null
    }

    private fun doWrite(data: ByteArray): Boolean {
        writeInFlight = true
        val ok = ble.write(data)
        if (ok) log.tx("FF02", data) else writeInFlight = false
        return ok
    }

    fun onWriteDone(ok: Boolean) {
        writeInFlight = false
        when (state) {
            State.SENDING_D5 -> {
                if (!ok) { fail("GATT báo lỗi khi gửi D5"); return }
                if (early81) { accept81() }
                else {
                    setState(State.WAIT_81, "Chờ phản hồi 81")
                    h.postDelayed(timeout81, 15_000)
                }
            }
            State.SENDING_D6 -> {
                if (!ok) { fail("GATT báo lỗi khi gửi gói D6 #${idx + 1}"); return }
                sentBytes += packets[idx].size - 1
                idx++
                emitProgress()
                when {
                    idx >= packets.size -> finishD6()
                    pauseReq -> { pauseReq = false; setState(State.PAUSED, "Tạm dừng tại gói $idx/${packets.size}") }
                    else -> h.postDelayed(sendNextRunnable, intervalMs)
                }
            }
            else -> { /* đã hủy / lỗi: bỏ qua callback muộn */ }
        }
    }

    private fun accept81() {
        h.removeCallbacks(timeout81)
        setState(State.READY_TO_SEND_D6, "Đã nhận 81 hợp lệ")
        t0 = SystemClock.elapsedRealtime()
        setState(State.SENDING_D6, "Đang gửi D6")
        sendNextD6()
    }

    private fun sendNextD6() {
        if (state != State.SENDING_D6 || writeInFlight) return
        if (idx >= packets.size) { finishD6(); return }
        if (!doWrite(packets[idx])) fail("Không thể ghi gói D6 #${idx + 1}")
    }

    private fun finishD6() {
        setState(State.WAIT_82, "ĐÃ GỬI HẾT FILE – ĐANG CHỜ ĐỒNG HỒ XÁC NHẬN")
        if (early82) accept82()
    }

    private fun accept82() {
        setState(State.COMPLETE, "TRUYỀN DỮ LIỆU HOÀN TẤT")
    }

    fun onRx(data: ByteArray) {
        log.rx("FF01", data)
        when (state) {
            State.SENDING_D5, State.WAIT_81 -> when (Protocol.match(data, 0x81, Protocol.EXPECTED_81)) {
                Protocol.Match.OK ->
                    if (state == State.SENDING_D5) early81 = true else accept81()
                Protocol.Match.STRUCT_ONLY ->
                    log.info("Gói giống 81 (đúng độ dài + tiền tố) nhưng KHÁC mẫu -> không chấp nhận")
                Protocol.Match.NO -> log.info("RX không phải 81, bỏ qua")
            }
            State.SENDING_D6 -> {
                if (Protocol.match(data, 0x82, Protocol.EXPECTED_82) == Protocol.Match.OK &&
                    writeInFlight && idx == packets.size - 1) early82 = true
                else log.info("RX trong lúc đang gửi D6, chỉ ghi nhật ký")
            }
            State.WAIT_82 -> when (Protocol.match(data, 0x82, Protocol.EXPECTED_82)) {
                Protocol.Match.OK -> accept82()
                Protocol.Match.STRUCT_ONLY ->
                    log.info("Gói giống 82 nhưng KHÁC mẫu -> không báo hoàn tất")
                Protocol.Match.NO -> log.info("RX không phải 82, bỏ qua")
            }
            else -> {}
        }
    }

    fun pause() {
        if (state != State.SENDING_D6) return
        if (writeInFlight) { pauseReq = true; log.info("Yêu cầu tạm dừng – chờ gói đang gửi xong") }
        else { h.removeCallbacks(sendNextRunnable); setState(State.PAUSED, "Tạm dừng tại gói $idx/${packets.size}") }
    }

    fun resume() {
        if (pauseReq) { pauseReq = false; log.info("Hủy yêu cầu tạm dừng"); return }
        if (state != State.PAUSED) return
        setState(State.SENDING_D6, "Tiếp tục từ gói ${idx + 1}")
        sendNextD6()
    }

    fun cancel() {
        if (!busy) return
        stopTimers()
        setState(State.CANCELLED, "CANCELLED – đã hủy, không gửi thêm")
    }

    fun fail(msg: String) {
        stopTimers()
        setState(State.ERROR, msg)
    }

    /** Gọi khi BLE báo mất kết nối. Không tự tiếp tục phiên cũ. */
    fun onDisconnected() {
        stopTimers()
        when {
            busy -> setState(State.ERROR, "Mất kết nối giữa chừng – phải kết nối lại và bắt đầu phiên mới")
            state == State.ERROR -> {}
            else -> setState(State.DISCONNECTED, "Đã ngắt kết nối")
        }
    }

    fun shutdown() { stopTimers(); if (busy) state = State.CANCELLED }

    private fun stopTimers() {
        h.removeCallbacks(timeout81); h.removeCallbacks(sendNextRunnable)
        pauseReq = false
    }

    private fun emitProgress() {
        val el = (SystemClock.elapsedRealtime() - t0).coerceAtLeast(1)
        val bps = if (t0 == 0L) 0 else sentBytes * 1000 / el
        onProgress?.invoke(Progress(sentBytes, totalBytes, idx, packets.size, bps))
    }
}
